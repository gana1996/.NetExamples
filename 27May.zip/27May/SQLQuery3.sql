create proc spDeptFetch
as begin
	select * from dept
	
end

exec spDeptFetch