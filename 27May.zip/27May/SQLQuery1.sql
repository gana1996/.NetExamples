--To create a database
create database April2019;


--To activate database
use April2019

--To rename a database
sp_renamedb "April2019","Apr19"

--To drop a database
drop database Apr19;

--To create a table
create table dept(deptno int primary key,dname varchar(20),location varchar(20) )

create table emp(empno int primary key,ename varchar(20) default 'Gana',
sal decimal check(sal between 10000 and 90000),mgr int, hiredate date not null,
ssn  varchar(15) unique,deptno int references dept(deptno))

--To view the structure of a table
sp_columns dept

sp_columns emp

--To alter a  table
create table employee(empno int,age int,firstname varchar(20),lastname varchar(20),deptno int)

--Alter an existing column lastname size to 50
alter table employee alter column lastname varchar(50)

sp_columns employee

--Adding Unique constraint to employee number
alter table employee add constraint emp_unq unique(empno)

--Adding depno as foreign key to dept table deptno
alter table employee add constraint fk_deptno foreign key(deptno) references dept(deptno)

--Adding check key constraint to ensure age must be greater than or  equal to 18
alter table employee add  constraint chk_age check(age>=18)

--creating a table with constraints
create table employee1(empno int identity(1001,1) primary key,empname varchar(50),dateofbirth date,
doj date,
designation varchar(10),
salary float constraint chk check(salary<200000),
mgr int foreign key references employee1(empno),
deptno int foreign key references dept(deptno)
)

--To insert records into Dept table
insert into dept VALUES(10,'Account','Delhi')
 
--To insert multiple records
insert INTO dept(deptno,dname,location)
values(20,'IT','Mumbai'),
(30,'Admin','Chennai'),
(40,'Operations','hYDERABAD')

INSERT INTO emp VALUES(1001,'Harish',21000,1007,'10-feb-2018','A001',10)
INSERT INTO emp VALUES(1002,'John',35000,1007,'10-mar-2017','A008',20)
INSERT INTO emp VALUES(1003,'Peter',40000,1007,'10-feb-2016','A002',30)
INSERT INTO emp VALUES(1004,'Yousuf',45000,1008,'10-dec-2015','A003',30)
INSERT INTO emp VALUES(1005,'Manoj',50000,1008,'10-oct-2014','A004',20)
INSERT INTO emp VALUES(1006,'Robert',70000,1007,'10-jan-2013','A005',20)
INSERT INTO emp VALUES(1007,'Andy',80000,1008,'10-feb-2008','A006',30)
INSERT INTO emp VALUES(1008,'Josh',90000,null,'10-feb-2007','A007',20)
insert into emp(empno,sal,mgr,hiredate,ssn,deptno) values(1009,90000,null,'11-sep-2007','A009',30)



--To view records in a table
select * from dept;
select * from emp

--Where clause
--List the employees whose salary is more than 50000

select * from emp where sal>50000

--List the employees who are working for depno 20
select * from emp where deptno=20;

--List the employees who are not working for depno 20
select * from emp where deptno<>20

--Between

---List the employees whose salary is between 50000 and 80000 inclusive
select * from emp where sal>=50000 and sal<=80000
--(Or)
select * from emp where sal between 50000 and 80000

--IN operator
--List the employees who are working for deptno 10 or 20
select * from emp where deptno=10 or deptno=20
--(Or)
select * from emp where deptno in (10,20)

--LIKE operator
--List the employee names are starting with S
select * from emp where ename like 'J%'

--List the employees the third character of their names must be 's'
select * from emp where ename like '__s%'

--List the employees who joined in the year 2010
select * from emp where hiredate like '2007%'

--Orderby clause
--List the employees in Ascending order of their deptno
select * from emp order by deptno asc;
--(or)
select * from emp order by 7;

--List the emp in ascending order of their deptno and descebding oder of their salarie
select empno,ename,deptno,sal from emp order by deptno asc,sal desc
---(Or)
select empno,ename,deptno,sal from emp order by 3 asc,4 desc

---DML Commands
--Updating Records
---Update SSN to A010 for empno 1009

update emp set ssn='A010'where empno=1009

--Update ename to Anish for empno 1001
update emp set ename='Anish' where empno=1001

--Increase salary of all employees to 1000 whose salary is <80000

update emp set sal=sal+1000 where sal<80000

--Update ename to Akash and sal to 48000 for empno 1002
update emp set ename='Akash',sal=48000 where empno=1002

--Delete records from a table
--Delete record 1009 from emp table
delete from emp where empno=1009
select * from emp

--Delete all records from emp table
delete from emp
--Truncate a table
truncate table emp

--To drop a table
drop table emp

-- Inner Join
select empno,ename,sal,deptno,dname,location from emp,dept where emp.deptno=dept.deptno


-Outer join: 
--It can be classified into 3 types
--1.Let outer join 2. Right outer join 3. Full outer join

--Left outer join-Returns matched records from 2 tables and unmatched reords from left side table

select empno,ename,sal,dept.deptno,deptname,location from dept left outer join emp on
  dept.deptno = emp.deptno

  --right outer join : Returns matched records from 2 tables and unmatched records from right side  table

  select empno,ename,sal,dept.deptno,deptname,location from emp right outer join dept on 
  emp.deptno= dept.deptno

  --Full outer join : Returns matched and unmatched records from two tables

   select empno,ename,sal,dept.deptno,deptname,location from emp full  outer join dept on 
  dept.deptno= emp.deptno

  --cross join : product of two table rows
  --Each row of first table is associated with each and every row of the second table

  select empno,ename,emp.deptno,deptname from emp cross join dept 

  --Self join:  In self join a table can join to itself
  
  select*from emp 

  select e1.empno,e1.ename,e2.ename Manager from emp e1, emp e2 where e1.mgr=e2.empno
  
  
----------------------------------------------------------------------------------


declare @x as int,@y as int
set @x=100
set @y=200
print @x+@y

--Example for exception handling

BEGIN TRY	
	DECLARE @NUM AS INT
	SET @NUM=100/10
	PRINT 'DIVISION'
	PRINT @NUM
END TRY
BEGIN CATCH
	PRINT 'NUMBER CANNOT BE DIVIDED BY ZERO'
END CATCH




--Example for exception handling

begin try
	update dept set dname='F&S' where deptno=10
	print 'Dept table updated'
begin try
	print 'Inserting a record in dept table'
	insert into dept values(10,'IT','Kolkata')
end try
	begin catch
	print 'Record is not inserted'
	print ERROR_MESSAGE();
END CATCH
END TRY
BEGIN CATCH
	PRINT 'RECORD IS NOT UPDATED'
	print ERROR_MESSAGE();
END CATCH

---------------------------------------------------------------------

-----------------Syntax Stored Procedures-----------
create procedure procedurename
parameters
as begin

Statement(s)

end

----Example for stored procedure to fetch records from a table

alter procedure spExample1
as begin
select empno,ename,sal,hiredate from emp
end

execute spExample1
--------------------------------------------------

----Example for stored procedure  with parameters

alter proc spExample2
@sal decimal,
@dno int
as begin
select empno,ename,sal,deptno from emp where sal>@sal and deptno=@dno
end

execute spExample2 30000,20


---

------------------------------------------------


---Example for stored procedure to insert records into a table into a table

create procedure spExample3
@dno int,
@name varchar(20),
@loc varchar(20)
as begin
begin try
 insert into dept(deptno,dname,location)values(@dno,@name,@loc)
 print 'Record inserted succesfully'
 end try
 begin catch
 print 'Record is not inserted'
 print ERROR_MESSAGE()
 END catch

 end

 exec spExample3 60,'Finance','Delhi'


---------------------------------

--Example to Update3
create procedure spDeptUpdate
@dno int,
@name varchar(20),
@loc varchar(20)
as begin
begin try
 update dept set dname=@name,location=@loc where deptno=@dno
 print 'Record updated succesfully'
 end try
 begin catch
 print 'Record is not updated'
 print ERROR_MESSAGE()
 END catch
end

exec spDeptUpdate 10,'IT','Pune'

select * from dept

---Example for deleting a record
create procedure spDeptDelete
@dno int

as begin
begin try
 delete from dept where deptno=@dno
 print 'Record deleted succesfully'
 end try
 begin catch
 print 'Record is not deleted'
 print ERROR_MESSAGE()
 END catch
end

exec spDeptDelete 60 


---------------------------------------
--Example for Output parameter
create proc spEmp1

@eno int,
@sal decimal output
as begin
	update emp set @sal=sal*(0.05) where empno=@eno
end

declare @res decimal

exec spEmp1 1001,@res output
print @res
-------
---VIEWS
--Simple View Example

alter view viewEx1 as select empno,ename,deptno,hiredate from emp where deptno=20

sp_columns viewEx1

select * from viewEx1

---------------------------------------------------------
--Inserting records into a view
insert into viewEx1 values(1,'Srujana',10,'11-sep-2017')

drop view viewEx1



------------------------------------------
--Example for transaction

create table BillingAddress(custno int,street varchar(15),city varchar(15))
create table MailingAddress(custno int,street varchar(15),city varchar(15))

insert into BillingAddress values(1001,'Miyapur','Hyderabad')
insert into MailingAddress values(1001,'Miyapur','Hyderabad')

select * from BillingAddress
select * from MailingAddress

alter proc spUpdateAddress
as begin
	begin try

	begin transaction
	update BillingAddress set street='Ramnagar',city='Bengaluru' where custno=1001
	update MailingAddress set street='Ramnagar',city='Bengaluru' where custno=1001
	print 'Transaction successful'
	commit transaction
	end try
	begin catch
	rollback transaction
	print 'Transaction failed!!'
	end catch
end

exec spUpdateAddress
	