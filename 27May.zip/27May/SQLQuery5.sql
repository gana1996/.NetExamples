create proc [dbo].[spDeptInsert]
@dno int,
@name varchar(20),
@loc varchar(20)
as begin
begin try
insert into dept(deptno,dname,location)values(@dno,@name,@loc)
print 'record inserted successfully'
end try
begin catch
print 'record is not inserted'
print ERROR_MESSAGE()
end catch
end

