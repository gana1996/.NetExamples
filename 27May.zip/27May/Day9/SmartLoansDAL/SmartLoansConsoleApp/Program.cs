﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartLoansDAL;

namespace SmartLoansConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //1. add reference to  DAL.dll  2.create an instance of rep.
            SmartLoansRepo repo = new SmartLoansRepo();
            var myUsers= repo.GetAllUsers();
            foreach (var user in myUsers)
            {
                Console.WriteLine(user.UserId+"\t\t"+user.UserName+"\t\t"+user.UserType);
            }

            //    //add user  method call
            //  bool added=  repo.AddUser(112,"Kashif", "Acc1234$$",2);
            //    if(added)
            //    Console.WriteLine("Congrats mama");
            //else
            //        Console.WriteLine("Oops");

            //3.calling update
            //bool updated = repo.UpdateUser(102, "Bharadwaj Karnati", "Acc1234$$", 2);
            //if(updated)
            //    Console.WriteLine("Congrats updated");
            //else
            //    Console.WriteLine("Oops");

            //4.calling delete
            bool deleted = repo.DeleteUser(112);
            if(deleted)
                Console.WriteLine("Congrats deleted");
            else
                Console.WriteLine("OOps");

            //5.GetLoanByUserId

            var listLoans = repo.GetLoansByUserId(104);
            foreach (var loan in listLoans)
            {
                Console.WriteLine(loan.UserId + "\t\t" + loan.LoanAmount);
            }
            //6.GetLoansByName
            var myLoans = repo.GetLoansByUserName("Dhamini");
            foreach(var l in myLoans)
            {
                Console.WriteLine(l.LoanAmount+":"+l.Status);
            }
        }
    }
}