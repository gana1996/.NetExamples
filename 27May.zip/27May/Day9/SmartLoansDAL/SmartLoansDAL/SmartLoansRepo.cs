﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartLoansDAL
{
    public class SmartLoansRepo
    {

        //write all the CRUD operations using EF here
        private SmartLoansDBContext context;

        public SmartLoansRepo()
        {
            context = new SmartLoansDBContext();
        }

        //1.GetAllUsers()
        public List<User> GetAllUsers()
        {
            List<User> lstUsers = new List<User>();

            //ur logic

            lstUsers = context.Users.ToList();//method syntax
            return lstUsers;
        }

        //2.Add User

        public bool AddUser(int userId,string userName,string password,int userType)
        {
            bool status = false;
            try
            {
                User temp = new User { UserId = userId,
                    UserName = userName,
                    Password = password,
                    UserType = userType
                };
                context.Users.Add(temp);
                context.SaveChanges();
                status = true;
            }
            catch(Exception ex)
            {
                status = false;
            }
            return status;
        }

        //3.Update
        public bool UpdateUser(int userId,string userName,string password,int userType)
        {
            bool status = false;
            try
            {
                User temp = context.Users.Where(u => (u.UserId == userId)).SingleOrDefault();
                temp.UserName = userName;
                temp.Password = password;
                temp.UserType = userType;
                context.SaveChanges();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }

        //4.Delete

        public bool DeleteUser(int userId)
        {
            bool status = false;
            try
            {
                User temp = context.Users.Where(u => (u.UserId == userId)).SingleOrDefault();
                context.Users.Remove(temp);
                context.SaveChanges();
                status = true;
            }
            catch(Exception  e)
            {
                status = false;
            }
            return status;
        }

        //////5.GetLoansByUserId
        //public List<Loan> GetLoansByUserId(int userId)
        //{
        //List<Loan> lstLoans = new List<Loan>();
        //lstLoans=context.Loans.Where(u => (u.UserId == userId)).ToList();
        //    return lstLoans;
        //}

        //6.GetLoanByUserName   by calling stored proc

        public List <usp_SearchLoans_Result> GetLoansByUserName(string name)
        {
            List<usp_SearchLoans_Result> lstLoans = new List<usp_SearchLoans_Result>();
            try
            {
                lstLoans = context.usp_SearchLoans(name).ToList();
            }
            catch(Exception e)
            {
                lstLoans =null;
            }
            return lstLoans;
        }
        //7.GetLoansByUserId with query syntax
        public List<Loan> GetLoansByUserId(int userId)
        {
            List<Loan> lstLoans = new List<Loan>();
            lstLoans = (from l in context.Loans where l.UserId == userId select l).ToList();
            return lstLoans;
        }

        //8.

    }
}
