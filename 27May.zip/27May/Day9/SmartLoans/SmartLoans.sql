CREATE TABLE Users(UserId INT PRIMARY KEY,UserName VARCHAR(40),[Password] VARCHAR(40),
                 UserType INT CONSTRAINT usr_type_chk CHECK ( UserType IN( 1,2)) ) ;

INSERT INTO Users  VALUES (101,'akash','Acc1234$$',1);	 
INSERT INTO Users  VALUES (102,'bhardwaj','Acc1234$$',1);	 -- 1 is admin/staff
INSERT INTO Users  VALUES (103,'Charmi','Acc1234$$',1);	

INSERT INTO Users (UserId,UserName,[Password],UserType) VALUES
                  (104,'Dhamini','Acc1234$$',2),
				  (105,'Dolanand','Acc1234$$',2),
				  (106,'Eshwar','Acc1234$$',2),
				  (107,'Farha','Acc1234$$',2),
				  (108,'Ganapathi','Acc1234$$',2),
				  (109,'Hussain','Acc1234$$',2),
				  (110,'Ishika','Acc1234$$',2),
				  (111,'Jadhav','Acc1234$$',2);
		



SELECT *FROM Users

--   ============================================================  --

--loans table

CREATE TABLE Loans(LoanId INT CONSTRAINT loan_id_pk PRIMARY KEY IDENTITY(201,1),
                   LoanAmount DECIMAL NOT NULL , 
				   UserId INT CONSTRAINT loan_user_id_fk REFERENCES Users(UserId),
				   [Status] VARCHAR(20) );
				   
INSERT INTO Loans (LoanAmount,UserId,[Status]) VALUES(200000,104,'applied')				   
INSERT INTO Loans (LoanAmount,UserId,[Status]) VALUES(300000,105,'applied')				   
INSERT INTO Loans (LoanAmount,UserId,[Status]) VALUES(400000,106,'approved')				   
INSERT INTO Loans (LoanAmount,UserId,[Status]) VALUES(500000,107,'rejected')

INSERT INTO Loans (LoanAmount,UserId,[Status]) VALUES(500000,222,'approved')

SELECT *FROM Users
SELECT *FROM Loans

















