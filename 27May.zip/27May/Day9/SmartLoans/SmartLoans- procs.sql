
CREATE PROC [dbo].[usp_SearchLoans](@UserName VARCHAR(40) ) 
AS
BEGIN

SELECT u.UserName,l.LoanAmount, l.[Status] FROM Users u JOIN Loans l
ON u.UserId=l.UserId AND u.UserName=@UserName

END;


