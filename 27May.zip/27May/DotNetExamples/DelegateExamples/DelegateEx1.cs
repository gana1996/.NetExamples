﻿////Example for Simple Cast Delegate
//using System;
//public delegate void MyDelegate();   //Declartion
//    class MyClass
//    {
//        public static void PrintMessage()
//        {
//        Console.WriteLine("Welcome to Accenture");
//        }

//    static void Main(string[] args)
//    {
//        MyDelegate md = new MyDelegate(PrintMessage);  //Instantiation
//        md();  //Invocation 

//    }
//    }
