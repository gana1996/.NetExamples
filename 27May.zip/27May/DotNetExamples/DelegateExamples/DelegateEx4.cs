﻿////Example for Covariance
//using System;

//class Shape
//{

//}
//class Rectangle : Shape
//{
//    public override string ToString()
//    {
//        return "I'm Rectangle";
//    }

//    class Circle : Shape
//    {
//        public override string ToString()
//        {
//            return "I'm Circle";
//        }
//    }


//    class MainClass
//    {
//        public delegate Shape ShapeDelegate();
//        public static Rectangle GetRectangle()
//        {
//            return new Rectangle();
//        }
//        public static Circle GetCircle()
//        {
//            return new Circle();
//        }
//        static void Main(string[] args)
//        {
//            ShapeDelegate sd1 = GetRectangle;
//            ShapeDelegate sd2 = GetCircle;
//            Console.WriteLine(sd1());
//            Console.WriteLine(sd2());
//        }
//    }
//}
