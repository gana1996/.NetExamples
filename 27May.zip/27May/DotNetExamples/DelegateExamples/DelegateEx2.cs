﻿////Example
//using System;
//public delegate int SumProductDelegate(int x, int y);
//    class Calculations
//    {
//    public int PrintSum(int x,int y)
//        {
//        return x + y;
//         }
//    public int PrintProduct(int x, int y)
//    {
//        return x * y;
//    }

//    static void Main(string[] args)
//    {
//        Calculations c1 = new Calculations();
//        SumProductDelegate sd = c1.PrintSum;  //Delegate inference instead of (new SumProductDelegate)
//        SumProductDelegate pd = new SumProductDelegate(c1.PrintProduct);
//        Console.WriteLine("Sum  "+sd(10,20));
//        Console.WriteLine("Product  "+pd(20,30));
//    }
//}
