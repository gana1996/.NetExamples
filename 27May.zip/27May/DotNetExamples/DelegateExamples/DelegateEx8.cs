﻿////Example for Asynchronous Delegate calls
//using System;
//class TeamManager
//{
//    public delegate void DevelopmentHamdler();
//    public void DeliverChangeRequest()
//    {
//        Console.WriteLine("1.Estimation delivered- by manager");

//        DevelopmentHamdler dev = ImplementChanges;
//        IAsyncResult result = dev.BeginInvoke(null, null);

//        Console.WriteLine("2.Updated task in Ms Project server-by manager");
//        Console.WriteLine("3.Updated requirements documnents-by manager");
//        dev.EndInvoke(result);
//        Console.WriteLine("7.Change request delivered- by manager");
//    }

//    public void ImplementChanges()
//    {
//        Console.WriteLine("4.Impact analysis done");
//        Console.WriteLine("5.Updated design docs");
//        Console.WriteLine("6.Implement code changes- by dev");
//    }
//}
//class MainClass
//{
//    static void Main(string[] args)
//    {
//        new TeamManager().DeliverChangeRequest();
//        Console.ReadLine();
//    }
//}

