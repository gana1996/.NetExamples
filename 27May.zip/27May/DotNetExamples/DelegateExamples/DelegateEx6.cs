﻿////Example for Generic Delegate
//using System;
//public delegate T  GenDelegate<T>(T x,T y);
//    class MyClass
//    {
//    public static int AddIntegerValues(int x,int y)
//    {
//        return x + y;
//    }

//    public static double AddDoubleValues(double x,double y)
//    {
//        return x + y;
//    }

//    public static string ConcatStringValues(string x,string y)
//    {
//        return x + y;
//    }

//    static void Main(string[] args)
//    {
//        GenDelegate<int> intDel = AddIntegerValues;
//        Console.WriteLine(intDel(10,20));
//        GenDelegate<double> doubleDel = AddDoubleValues;
//        Console.WriteLine(doubleDel(3.75,4.62));
//        GenDelegate<string> stringDel = ConcatStringValues;
//        Console.WriteLine(stringDel("Rahul"," MR"));
//    }
//    }

