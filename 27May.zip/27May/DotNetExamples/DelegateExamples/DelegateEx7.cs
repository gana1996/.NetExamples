﻿////Example for Anonymous method
//using System;
//public delegate int SumDelegate(int x, int y);
//    class MyClass
//    {
//    static void Main(string[] args)
//    {
//        SumDelegate del = delegate (int x, int y) //Anonymous method--- no need to create seperate method
//          {
//              return x + y;
//          };
//        Console.WriteLine(del(10,20));
//    }
//    }

/////Delagate modes: Synchronous Delegate modes and Asynchronous Delegate Mode--methods gets executed parallelly(randomly- it is done with methods begin invoke and end invoke)