﻿////eXAMPLE FOR Contravariance
//using System;

//class Shape
//{
//    public override string ToString()
//    {
//        return "I'm Shape";
//    }
//}
//class Rectangle : Shape
//{
//    public override string ToString()
//    {
//        return "I'm Rectangle";
//    }
//}
   

//class MainClass
//{
//    public delegate Shape MyDelagate(Rectangle r);
//    public static Shape ShapeMethod(Shape s1)
//    {
//        return s1;
//    }
//    public static Shape RectangleMethod(Rectangle r1)
//    {
//        return r1;
//    }
//    static void Main(string[] args)
//    {
//        MyDelagate del1 = ShapeMethod;
//        Console.WriteLine(del1(new Rectangle ()).GetType());

//        MyDelagate del2 = RectangleMethod;
//        Console.WriteLine(new Rectangle().GetType());
//    }
//}
