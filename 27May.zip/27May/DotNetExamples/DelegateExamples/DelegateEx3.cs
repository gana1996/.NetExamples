﻿////Example for Multicast Delegate
//using System;

//public delegate void PrintDelegate();
//    class MyClass
//    {
//    public static void PrintMessage1()
//    {
//        Console.WriteLine("HDC");
//    }

//    public static void PrintMessage2()
//    {
//        Console.WriteLine(  "MDC");
//    }

//    public static void PrintMessage3()
//    {
//        Console.WriteLine("PDC");
//    }

//    static void Main(string[] args)
//    {
//        //PrintDelegate del1, del2, del3, del4;
//        //del1 = PrintMessage1;
//        //del2 = PrintMessage2;
//        //del3 = PrintMessage3;
//        //del4 = del1 + del2 + del3-del2;
//        //del4();

//        Console.WriteLine("2nd WAY");
//        PrintDelegate del = PrintMessage1;
//        del += PrintMessage2;
//        del += PrintMessage3;
//        del -= PrintMessage2;
//        del();
//    }
//    }

