﻿//Example for Race Condition
using System;
using System.Threading;


class ThreadEx5
{
    static int count = 0;
    static object lock1 = new object();
    public static void PrintValues()
    {
        for (int i = 1; i <= 5; i++)
        {
            lock (lock1)
            {
                int temp = count;
                Thread.Sleep(5);
                temp = temp + 1;
                count = temp;
            }
        }
    }

    static void Main(string[] args)
    {
        Thread thread1 = new Thread(PrintValues);
        thread1.Start();
        thread1.Join();
        Console.WriteLine(count);
    }
}

