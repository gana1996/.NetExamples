﻿////Example for ThreadStart Delegate
//using System;
//using System.Threading;

//class ThreadEx2
//{
//    public static void Child()
//    {
//        Console.WriteLine("Inside the child thread");
//    }

//    static void Main(string[] args)
//    {
//        ThreadStart threadDelegate = new ThreadStart(Child);
//        Thread childThread = new Thread(threadDelegate);
//        Console.WriteLine(childThread.ThreadState);
//        childThread.Start();
//        Thread.Sleep(1000);
//        Console.WriteLine(childThread.ThreadState);

//    }
//}