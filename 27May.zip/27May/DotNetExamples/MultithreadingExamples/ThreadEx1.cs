﻿////Examplr for Multithreading USING ThreadStart Delegate
//using System;
//using System.Threading;

//class ThreadEx1
//{
//    public static void PrintValues1()
//    {
//        for (int i = 1; i <= 10; i++)
//        {
//            Console.WriteLine("PrintvALUES1: " + i);
//            Thread.Sleep(2000);
//        }
//    }
//    public static void PrintValues2()
//    {
//        for (int i = 1; i <= 10; i++)
//        {
//            Console.WriteLine("PrintvALUES2: " + i);
//            Thread.Sleep(2000);
//        }
//    }

//    static void Main(string[] args)
//    {
//        //ThreadStart t1 = new ThreadStart(PrintValues1);
//        //Thread thread1 = new Thread(t1);

//        //ThreadStart t2 = new ThreadStart(PrintValues2);
//        //Thread thread2 = new Thread(t2);

//        //thread1.Start();
//        //thread2.Start();

//        //(or)

//        Thread thread1 = new Thread(PrintValues1);
//        Thread thread2 = new Thread(PrintValues2);
//        thread1.Start();
//        thread2.Start();
//    }
//}