﻿////Example for Thread Priorities
//using System;
//using System.Threading;

//class ThreadEx4
//{
//    public static void PrintStatus()
//    {
//        Console.WriteLine(Thread.CurrentThread.Name);
//    }
//    static void Main(string[] args)
//    {
//        ThreadStart t1 = new ThreadStart(PrintStatus);
//            Thread th1 = new Thread(t1);
//        th1.Name = "Child1";
//        Thread th2 = new Thread(t1);
//        th2.Name = "Child2";
//        th1.Priority = ThreadPriority.BelowNormal;
//        th2.Priority = ThreadPriority.Normal;
//        th1.Start();
//        th2.Start();

//    }
//}
