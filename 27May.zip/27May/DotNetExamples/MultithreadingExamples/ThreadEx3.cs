﻿////Example for 
//using System;
//using System.Threading;

//    class ThreadEx3
//    {
//    public static void PrintValues()
//    {
//        for(int i=0;i<=5;i++)
//        {
//            if(i==5)
//            {
//                Thread.CurrentThread.Abort();
//            }
//            Console.WriteLine("Thread1 in action ");
//            Thread.Sleep(5);
//        }
//    }
//    static void Main(string[] args)
//    {
//        Thread thread1 = new Thread(PrintValues);
//        thread1.IsBackground = true;
//        thread1.Start();
//        Console.WriteLine(thread1.ThreadState);
//        if(thread1.IsAlive==true)
//        {
//            Console.WriteLine("Thread1 is alive");
//        }
//        Console.WriteLine("Main thread in Action");
//        thread1.Join();
//        if (thread1.IsAlive == false)
//        {
//            Console.WriteLine("Thread1 is not alive");
//        }
//        Console.WriteLine("Main thread in Action");
//        thread1.Join();
//    }
//    }

////backgroud thread will quit if main applicaion quits
////foreground thread will keep running though the main application quits