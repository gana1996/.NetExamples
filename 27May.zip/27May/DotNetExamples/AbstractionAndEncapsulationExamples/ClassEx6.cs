﻿//Example for Indexer
using System;

class Employee
{
	private string[] empName = new string[5];

	public string this[int index]
	{
		set
		{
			empName[index] = value;
		}
		get
		{
			return empName[index];
		}
	}

}
class MainClass
{
	static void Main(string[] args)
	{
		Employee e1 = new Employee();
		e1[0] = "Vivek Thatha";
		e1[1] = "Revanth Raja";
		e1[2] = "Sarkar";
		e1[3] = "Gupta";
		e1[4] = "Shivaji Maharaj";
		for (int i = 0; i < 5; i++)
		{
			Console.WriteLine(e1[i]);
		}
	}
}
