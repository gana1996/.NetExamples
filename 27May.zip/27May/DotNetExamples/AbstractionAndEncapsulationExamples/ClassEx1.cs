﻿////Example for Class Implementation
//using System;

//class Employee
//{

//	int empId;
//	string empName;
//	double empSal;

//	public void GetEmpDetails()
//	{
//		Console.WriteLine("Enter employee details");
//		empId = int.Parse(Console.ReadLine());
//		empName = Console.ReadLine();
//		empSal = double.Parse(Console.ReadLine());
//	}

//	public void PrintEmpDetails()
//	{
//		Console.WriteLine("Employee Id:" + empId);
//		Console.WriteLine("Employee Name:" + empName);
//		Console.WriteLine("Employee Salary:" + empSal);
//	}

//	static void Main(string[] args)
//	{
//		Employee emp = new Employee();
//		emp.GetEmpDetails();
//		emp.PrintEmpDetails();
//		Console.WriteLine("****************************");
//		Employee emp1 = new Employee();
//		emp1.GetEmpDetails();
//		emp1.PrintEmpDetails();
//	}
//}
