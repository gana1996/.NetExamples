﻿////Example for Encapsulation
//using System;

//class Rectangle
//{
//	private int length;
//	private int breadth;

//	public int Length { get => length; set => length = Math.Abs(value); }
//	public int Breadth { get => breadth; set => breadth = Math.Abs(value); }

//}
//class MainClass
//{
//	static void Main(string[] args)
//	{
//		Rectangle r1 = new Rectangle();
//		Console.WriteLine("Enter length and breadth");
//		r1.Length = int.Parse(Console.ReadLine());
//		r1.Breadth = int.Parse(Console.ReadLine());
//		Console.WriteLine("Area of Rectangle"+(r1.Length*r1.Breadth));
//	}
//}
