﻿////Example for Properties
//using System;

//class Employee
//{
//	public int empId { get; set; }  //Automatic Properties can be used when we don't have any business rules
//	public string empName { get; set; }
//	public int empSalary { get; set; }

//	public int EmpId { get => empId; set => empId = value; }
//	public string EmpName { get => empName; set => empName = value; }
//	public int EmpSalary { get => empSalary; set => empSalary = value; }

//	class MainClsass
//	{
//		static void Main(string[] args)
//		{
//			Employee emp1 = new Employee();
//			emp1.EmpId = 1001;
//			emp1.EmpName = "sai";
//			emp1.EmpSalary = 50000;
//			Console.WriteLine("Employee Id:" + emp1.EmpId);
//			Console.WriteLine("Employee Name:" + emp1.EmpName);
//			Console.WriteLine("Employee Salary:" + emp1.EmpSalary);
//		}
//	}
//}