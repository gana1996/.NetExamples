﻿////Example for Properties
//using System;

//class Employee
//{
//	private int empId;
//	private string empName;
//	private int empSalary;

//	public int EmpId
//	{
//		set
//		{
//			empId = value;

//		}
//		get
//		{
//			return empId;
//		}
//	}

//		public string EmpName
//	{
//		set
//		{
//			empName = value;

//		}
//		get
//		{
//			return empName;
//		}

//	}
//	public int EmpSal
//	{
//		set
//		{
//			empSalary = value;

//		}
//		get
//		{
//			return empSalary;
//		}
//	}
//	class MainClsass
//	{
//		static void Main(string[] args)
//		{
//			Employee emp1 = new Employee();
//			emp1.EmpId = 1001;
//			emp1.EmpName = "sai";
//			emp1.EmpSalary = 50000;
//			Console.WriteLine("Employee Id:"+emp1.EmpId);
//			Console.WriteLine("Employee Name:"+emp1.EmpName);
//			Console.WriteLine("Employee Salary:"+emp1.EmpSalary);
//		}
//	}
//}
