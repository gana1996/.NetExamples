﻿////Example for Binary Serialization
//using System;
//using System.IO;
//using System.Runtime.Serialization.Formatters.Binary;

//[Serializable]

//class Employee
//{
//    private int empNo;
//    private string empName;
//    [NonSerialized]
//    private double salary;

//    public int EmpNo { get => empNo; set => empNo = value; }
//    public string EmpName { get => empName; set => empName = value; }
//    public double Salary { get => salary; set => salary = value; }

//    public Employee(int empNo,string empName,double salary)
//    {
//        this.empNo = empNo;
//        this.empName = empName;
//        this.salary = salary;

//    }
//}


//class MainClass
//{
    

//    static void Main(string[] args)
//    {

    
//    Employee[] emp =
//    {
//        new Employee(1001,"Sai",8500.23),
//        new Employee(1002,"Raj",7500.23),
//        new Employee(1003,"Rajan",9500.23),
//    };

//    FileStream fs = new FileStream(@"C:\27MayExamples\EmpDetails.dat", FileMode.Create);
//    BinaryFormatter bin = new BinaryFormatter();
//    bin.Serialize(fs,emp);
//        fs.Close();
//        Console.WriteLine(  "Serialization is completed");

//        Employee[] emp1 = null;
//    fs=new FileStream(@"C:\27MayExamples\EmpDetails.dat", FileMode.Open);
//    emp1=(Employee[]) bin.Deserialize(fs);
//   fs.Close();
//        Console.WriteLine(  "Deserailization completed");
//        foreach(Employee x in emp1)
//        {
//        Console.WriteLine(  "Emp nO."+x.EmpNo);
//        Console.WriteLine(  "Emp Name:"+x.EmpName);
//        Console.WriteLine(  "Salary:"+x.Salary);
//        }

//    }
//}