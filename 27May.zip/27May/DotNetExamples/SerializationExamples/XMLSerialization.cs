﻿////Example for XML Serialization
//using System;
//using System.IO;
//using System.Xml.Serialization;

//public class Employee
//{
//    [XmlElement(ElementName ="Emp_Number")]
//    public int EmpNo { get; set;}
//    [XmlElement(ElementName = "Emp_Name")]
//    public string EmpName { get; set; }
//    [XmlElement(ElementName = "Salary")]
//    public double Salary { get; set; }
//    [XmlAttribute(AttributeName = "Emp_Number")]
//    public string Department { get; set;}

//}


//class MainClass
//{
//    static void Main(string[] args)
//    {
//        Employee e1 = new Employee
//        {
//            EmpNo = 1001,
//            EmpName = "Avinash",
//            Salary = 57000.00,
//            Department = "IT",
//        };

//        FileStream fs = new FileStream(@"C:\27MayExamples\EmpDetails1.xml", FileMode.Create);
//        XmlSerializer xs = new XmlSerializer(typeof(Employee));
//        xs.Serialize(fs, e1);
//        fs.Close();
//        Console.WriteLine("XML Serialization Completed");

//        Employee e2 = null;
//       fs = new FileStream(@"C:\27MayExamples\EmpDetails1.xml", FileMode.Open);
//        e2 = (Employee)xs.Deserialize(fs);
//        Console.WriteLine("Deserialization completed");
//        Console.WriteLine("Emp nO." + e2.EmpNo);
//         Console.WriteLine(  "Emp Name:"+e2.EmpName);
//             Console.WriteLine(  "Salary:"+e2.Salary);
//        Console.WriteLine("Department"+e2.Department);
//    }
//}          
