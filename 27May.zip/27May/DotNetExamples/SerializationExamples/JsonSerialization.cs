﻿//Example for Json Serialization
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

[DataContract]
public class Employee
{
    [IgnoreDataMember]
    public int EmployeeId { get; set;}
    [DataMember(Name ="firstname")]
    public string EmployeeName { get; set; }
    [DataMember(Name = "Skillset")]
    public string[] Skills { get; set; }

    static void Main(string[] args)
    {
        Employee emp = new Employee
        {
            EmployeeId = 101,
            EmployeeName = "Raja",
            Skills = new String[] { "C#", "SQL", "SAP" }
        };

        FileStream fs = new FileStream(@"C:\27MayExamples\Employee.txt", FileMode.OpenOrCreate, FileAccess.Write);
        DataContractJsonSerializer ds = new DataContractJsonSerializer(typeof(Employee));
        ds.WriteObject(fs, emp);
        fs.Close();
        Console.WriteLine("Serialization Complted");

        FileStream fs1 = new FileStream(@"C:\27MayExamples\Employee.txt", FileMode.Open, FileAccess.Read);
        Employee emp1 = (Employee)ds.ReadObject(fs1);
        Console.WriteLine("Deserialization Completed");
        Console.WriteLine("Employee id:"+emp1.EmployeeId);
        Console.WriteLine("Employee Name:"+emp1.EmployeeName);
        foreach (string skill in emp.Skills)
            {
            Console.WriteLine(skill);
        }


    }
}