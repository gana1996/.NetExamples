﻿////Example for String Builder
//using System;
//using System.Text;

//    class CoreUtilEx4
//    {
//    static void Main(string[] args)
//    {
//        StringBuilder sb = new StringBuilder("Welcome to Accenture Hyderabad", 30);
//        sb.Append(" hdc2 waverock building");
//        Console.WriteLine(sb.ToString());
//        sb.Insert(10, " Near ICICI Bannk");
//        Console.WriteLine(sb.ToString ());
//        sb.Remove(6, 21);
//        Console.WriteLine(sb.ToString());
//        sb.Replace('o', '0');
//        Console.WriteLine(sb.ToString());
//        Console.WriteLine("Lenght of the string:  "+sb.Length);
//    }
//    }
