﻿//Example for System.Math
using System;

    class CoreUtilEx5
    {
    private double length;
    private double breadth;
    private double height;
    private double radius;

    public CoreUtilEx5(double num1, double num2,double num3,double num4)
    {
        length = Math.Abs(num1);
        breadth = Math.Abs(num2);
        height = Math.Abs(num3);
        radius = Math.Abs(num4);

    }

    public double GetRectVol()
    {
        return (length * breadth * height);
    }

    public double CircleArea()
    {
        return (Math.PI*Math.Pow(radius,2.0));
    }


    public double GetSine()
    {
        return Math.Round(Math.Sin(height),2);
    }

    public double GetSquareRoot()
    {
        return Math.Round(Math.Sqrt(radius),2);
    }

  public  static void Main()
    {
        double value1 = 123.456;
        double ceiling1 = Math.Ceiling(value1);
        double floor1 = Math.Floor(value1);
        Console.WriteLine("Ceiling"+ceiling1);
        Console.WriteLine("Flooor"+floor1);
        CoreUtilEx5 sample = new CoreUtilEx5(10.0, 20.0, 40.0, 45);
        Console.WriteLine("The length=10,b=20,h=45,rad=40");
        double rectangleArea = sample.GetRectVol();
        Console.WriteLine("Rect vol is"+rectangleArea.ToString());

            
    }




