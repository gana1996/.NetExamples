﻿////Example for System.IO
//using System;
//using System.IO;

//    class CoreUtilEx2
//    {
//    static void Main(string[] args)
//    {
//        using (FileStream fs = new FileStream(@"C:\27MayExamples\gana.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite))
//        {
//            StreamWriter sw = new StreamWriter(fs);
//            sw.BaseStream.Seek(0, SeekOrigin.End);
//            sw.WriteLine("Welcome to Accenture HDC");
//            sw.WriteLine("WaveRock");
//            sw.WriteLine("Telangana");
//            sw.WriteLine("Time:" + DateTime.Now.ToLongTimeString());
//            sw.WriteLine("Time:" + DateTime.Now.ToLongDateString());
//            sw.Flush();
//            sw.Close();

//            StreamReader sr = new StreamReader(@"C:\27MayExamples\gana.txt");
//            string str;
//            while((str=sr.ReadLine())!=null)
//            {
//                Console.WriteLine(str);
//            }
//            sr.Close();
//        }
//    }
//    }

