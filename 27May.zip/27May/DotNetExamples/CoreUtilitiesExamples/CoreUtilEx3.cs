﻿////Example for System Reflection
//using System;
//using System.Reflection;


//    class CoreUtilEx3
//    {
//    public int Age { get; set;}
//    public string EmpName { get; set; }
//    public int empNo;

//    public void PrintMessage1()
//    {
//        Console.WriteLine("accenture");
//    }
//    public void PrintMessage2()
//    {
//        Console.WriteLine("IDC");
//    }
//}

//class MainClass
//{
//    static void Main(string[] args)
//    {
//        Type type = typeof(CoreUtilEx3);
//        MethodInfo[] methods = type.GetMethods();
//        PropertyInfo[] properties = type.GetProperties();
//        FieldInfo[] fields = type.GetFields();
//        Console.WriteLine("CoreUtilEx3 has below methods");
//        foreach(MethodInfo x in methods)
//        {
//            Console.WriteLine(x.Name);
//        }

//        Console.WriteLine("CoreUtilEx3 has below properties");
//        foreach (PropertyInfo x in properties)
//        {
//            Console.WriteLine(x.Name);
//        }

//        Console.WriteLine("CoreUtilEx3 has below attributes");
//        foreach (FieldInfo x in fields)
//        {
//            Console.WriteLine(x.Name);
//        }
//    }
//}

