﻿////Example for String Class
//using System;
//using System.Globalization;


//	class CoreUtilEx1
//	{
//		static void Main(string[] args)
//		{
//		string firstName = "John";
//        string lastName = "Williams";
//        Console.WriteLine(firstName.Clone());
//        Console.WriteLine(firstName.CompareTo(lastName)); //if firstname<lastname it prints -1 it checks the ascii values of the character
//        Console.WriteLine(firstName.Contains("ohn"));
//        Console.WriteLine(firstName.EndsWith("N"));
//        Console.WriteLine(firstName.Equals(lastName));
//        Console.WriteLine(firstName.IndexOf("n"));
//        Console.WriteLine(firstName.ToLower());
//        Console.WriteLine(lastName.ToUpper());
//        Console.WriteLine(firstName.Insert(0,"Puli"));
//        Console.WriteLine(firstName.Length);
//        Console.WriteLine(firstName.Remove(3));
//        Console.WriteLine( firstName.Replace("n","duck"));
//        string[] split = firstName.Split(new char[] { 'n' });
//        Console.WriteLine(split[0]);
//       // Console.WriteLine(split[1]);
//      //  Console.WriteLine(split[2]);

//        Console.WriteLine(firstName.StartsWith("j"));
//        Console.WriteLine(firstName.Substring(1,3));
//        string details = "Employee Details";
//        int salary = 5000;
//        DateTime doj = new DateTime(2019, 4, 19);
//        string result = string.Format("{0}:{1:0.0}:{2:dd}-{2:MMM}-{2:yyyy}", details, salary, doj, doj, doj);
//        Console.WriteLine(doj.Month);
//        Console.WriteLine( doj.ToString("MMM"));
//        Console.WriteLine(result);
//        Console.WriteLine(firstName.ToCharArray());
//        string str = "         accenture";
//        Console.WriteLine(str.Trim());
//		}
//	}
