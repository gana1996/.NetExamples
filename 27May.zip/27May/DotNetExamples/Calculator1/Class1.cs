﻿
using System;

namespace Calculator
{
    public class Calculations
    {
        public int PrintSum(int x, int y)
        {
            return x + y;
        }
        public int PrintSubtraction(int x, int y)
        {
            return x - y;
        }
        public int PrintProduct(int x, int y)
        {
            return x * y;
        }
        public int PrintDivision(int x, int y)
        {
            return x / y;
        }
    }
}
