﻿////Example for String Collection
//using System;
//using System.Collections;
//using System.Collections.Specialized;  //for string collection


//    class CollectionEx3
//    {
//    static void Main(string[] args)
//    {

//        StringCollection numbers = new StringCollection();
//        string[] myArray = new string[] { "One", "Two", "Three" };
//        numbers.AddRange(myArray);
//        Console.WriteLine("AFTER ADDING ELEMENTS");
//        PrintValues(numbers);
//        Console.WriteLine("*********************");
//        numbers.Add("Five");
//        numbers.Insert(3, "Three");
//        PrintValues(numbers);
//    }


//    public static void PrintValues(IEnumerable numbers)
//    {
//        IEnumerator IE = numbers.GetEnumerator();
//        while(IE.MoveNext())
//        {
//            Console.WriteLine(IE.Current);
//        }
//    }

//    }
