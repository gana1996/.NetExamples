﻿////Example for Hash Table-- values cannot be predicted becoz data is stored randomly
//using System;
//using System.Collections;


//    class CollectionEx5
//    {
//    static void Main(string[] args)
//    {
//        Hashtable ht = new Hashtable();
//        ht.Add("FIRST", "c#");
//        ht.Add("Second", "Java");
//        ht.Add("Third", "SAP");
//        Console.WriteLine("Value of key First is:"+ht["First"]);
//        Console.WriteLine("Keys and Values");
//        PrintValues(ht);
//    }

//    public static void PrintValues(Hashtable h)
//   {
//      IDictionaryEnumerator ide = h.GetEnumerator();
//        while(ide.MoveNext())
//       {
//            Console.WriteLine("Key:  "+ide.Key+  "Value:  "+ide.Value);
//      }
//    }
//}

