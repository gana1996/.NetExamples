﻿//using System;
//using System.Collections;

//    class CollectionEx2
//    {
//    static void Main(string[] args)
//    {
//        ArrayList myAl = new ArrayList();
//        myAl.Add("One");
//        myAl.Add("Two");
//        myAl.Add("Three");
//        Console.WriteLine("Count is"+myAl.Count);
//        PrintValues(myAl);
//        Console.WriteLine("***************");
//        myAl.Sort();
//        PrintValues(myAl);
//    }
//    public static void PrintValues(IEnumerable myList)
//    {
//        IEnumerator myEnumerator = myList.GetEnumerator();
//        while (myEnumerator.MoveNext())
//        {
//            Console.WriteLine(myEnumerator.Current);
//        }
//    }

//    }

