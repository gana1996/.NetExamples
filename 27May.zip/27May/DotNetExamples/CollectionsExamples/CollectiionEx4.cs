﻿////Example for Sorted List -----  we can enter data in any order the data gets sorted based on the key, we use IDictionary Enumerator to retrieve
////hash table data is stored randomly we cant predict it.
//using System;
//using System.Collections;

//    class CollectiionEx4
//    {
//    static void Main(string[] args)
//    {
//        SortedList sl = new SortedList();
//        sl.Add(1001, "vivek");
//        sl.Add(1005, "Rahul");
//        sl.Add(1009, "Oshika");
//        sl.Add(1003, "Monisha");
//        sl.Add(1004, "Zehra");
//        Console.WriteLine("Value of key 1001:"+sl[1001]);
//        Console.WriteLine("Key and Values");
//        PrintValues(sl);
//    }
//    public static void PrintValues(SortedList s)
//    {
//        IDictionaryEnumerator ide = s.GetEnumerator();
//        while(ide.MoveNext())
//        {
//            Console.WriteLine("Key:  "+ide.Key+  "Value:  "+ide.Value);
//        }
//    }

//    }
