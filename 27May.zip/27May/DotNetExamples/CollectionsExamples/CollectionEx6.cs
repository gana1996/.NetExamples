﻿//Example for Custom Collection
using System;
using System.Collections;

class Employee
    {
    int empId;
    string empName;
    string empCity;


    public Employee(int empId,string empName,string empCity)
    {
        this.empId = empId;
        this.empCity = empCity;
        this.empName = empName;
    }
    public void PrintData()
    {
        Console.WriteLine("Emp Id:"+empId);
        Console.WriteLine("Emp Name"+empName);
        Console.WriteLine("Emp City"+empCity);
    }
    }

class EmpCollection:CollectionBase
{
    public void Add(Employee emp)
    {
        List.Add(emp);
    }

    public void RemoveAt(int index)
    {
        List.RemoveAt(index);
  
    }
    public void Insert(int index,Employee emp)
    {
        List.Insert(index, emp);
    }
}

class MainClass
{
    static void Main(string[] args)
    {

        EmpCollection ec = new EmpCollection();
        ec.Add(new Employee(1001, "Sai", "kOlakata"));
        ec.Add(new Employee(1002, "Sai bABU", "mUMBAI"));
        ec.Add(new Employee(1003, "Sai kRISH", "HYD"));
        ec.Add(new Employee(1004, "Sai RAM", "CHENNAI"));
        
        foreach(Employee x in ec)
        {
            x.PrintData();
        }

        Console.WriteLine("\nAfter inserting an item in 2nd position");
        Employee e1 = new Employee(1005, "Rahul", "Bangalore");
        ec.Insert(1, e1);

        foreach (Employee x in ec)
        {
            x.PrintData();
        }
        Console.WriteLine("\n After removing last item");
        ec.RemoveAt(4);

        foreach (Employee x in ec)
        {
            x.PrintData();
        }
    }
}

