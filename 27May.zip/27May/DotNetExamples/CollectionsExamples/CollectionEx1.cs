﻿////Example for Array List
//using System;
//using System.Collections;

//class CollectionEx1
//{
//    static void Main(string[] args)
//    {

//        ArrayList locations = new ArrayList();
//        locations.Add("HDC");
//        locations.Add("MDC");
//        locations.Add("BDC");
//        locations.Add("PDC");
//        locations.Add("CDC");
//        locations.Add("DDC");
//        locations.Add(10);
//        locations.Add(20);
//        Console.WriteLine("No. Of Locations" + locations.Count);
//        locations.RemoveAt(0);
//        locations.Remove("DDC");
//        Console.WriteLine("No. Of Locations" + locations.Count);
//        foreach(object x in locations)
//        {
//            Console.WriteLine(x);

//        }
//        Console.WriteLine("*****************");
//        locations.Remove(10);
//        locations.Remove(20);
//        locations.Sort();
//          foreach (object x in locations)
//        {
//            Console.WriteLine(x);
//        }
//    }
//}