﻿////Example for Multilevel Inheritance
//using System;

//class Employee
//{
//	private int empId;
//	private string empName;

//	public int EmpId
//	{
//		get { return empId; }
//	}

//	public string EmpName
//	{
//		get { return empName; }
//	}

//	public  Employee(int empId,string empName)
//	{
//		this.empId = empId;
//		this.empName = empName;
//	}
//}


//class Trainer : Employee
//{
//	private int trainingDays;

//	public int TrainingDays
//	{
//		set { trainingDays = value; }
//		get { return trainingDays; }
//	}
//	public Trainer(int empId,string empName,int trainingDays):base(empId,empName)
//	{
//		this.trainingDays = trainingDays;
//	}
//}

//class TechnicalTrainer:Trainer
//{
//	protected string technology;

//	public TechnicalTrainer(int empId,string empName,int trainingDays,string technology): base(empId, empName,trainingDays)
//	{
//		this.technology = technology;
//	}

//	public void PrintDetails()
//	{
//		Console.WriteLine("Empid:"+EmpId);
//		Console.WriteLine("Empname:"+EmpName);
//		Console.WriteLine("TrainingDays:"+TrainingDays);
//		Console.WriteLine("Technology:"+technology);
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{
//		TechnicalTrainer t1 = new TechnicalTrainer(101,"Rahul",90,".Net");
//		t1.PrintDetails();
//	}
//}