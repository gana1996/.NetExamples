﻿////Example for Single Inheritance
//using System;

//class Employee
//{
//	private int empId;
//	private string empName;

//	public int EmpId
//	{
//		get { return empId; }
//	}

//	public string EmpName
//	{
//		get { return empName; }
//	}

//	public Employee(int empId,string empName)
//	{
//		this.empId = empId;
//		this.empName = empName;

//	}
//}
//class Participant:Employee
//{
//	private double[] marks = new double[3];

//	public double[] Marks
//	{
//		set { marks = value; }
//		get { return marks; }
//	}

//	public Participant(int empId,string empName,double[] marks):base(empId,empName)
//	{
//		this.marks = marks;
//	}
//	public void PrintDetails()
//	{
//		Console.WriteLine("EmpId:"+EmpId);
//		Console.WriteLine("EmpName:"+EmpName);
//		Console.WriteLine("Marks in respective subjects"	);
//		foreach(double x in marks)
//		{
//			Console.WriteLine(x) ;
//		}
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{
//		double[] marks = { 100, 99, 96 };
//		Participant p1 = new Participant(100,"Rahul",marks);
//		p1.PrintDetails();
//	}
//}


	