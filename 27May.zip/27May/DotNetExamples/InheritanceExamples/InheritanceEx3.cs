﻿//Example for Constructor Chaining
using System;

class Employee
{
	public Employee()
	{
		Console.WriteLine("Employee class Default Constructor");
	}
}

class Participant : Employee
{
	public Participant()
	{
		Console.WriteLine("Participant classs Default Constructor");
	}
}
class MainClass
{
	static void Main(string[] args)
	{
		new Participant();
		Console.Read();
	}
}