﻿//Example for Generic Collection
using System;
using System.Collections.Generic;


class Employee
{
    public int empid { get; set; }
public string empname { get; set; }
    }
class GE6
{
    static void Main(string[] args)
    {
        List<int> intList = new List<int>();
        intList.Add(10);
        intList.Add(100);
        intList.Add(1022);

        foreach (int x in intList)
        {
            Console.WriteLine(x + "\t");
        }


        List<string> strList = new List<string>();
        strList.Add("ab");
        strList.Add("abd");
        strList.Add("abcd");

        foreach (string x in strList)
        {
            Console.WriteLine(x + "\t");

        }

        List<bool> bList = new List<bool>();
        bList.Add(true);
        bList.Add(false);
        //trList.Add("abcd");

        List<Employee> empList = new List<Employee>();
        empList.Add(new Employee { empid = 100, empname = "moni" });
        empList.Add(new Employee { empid = 102, empname = "monika" });
        foreach (Employee x in empList)
        {
            Console.WriteLine("Empid is:" + x.empid + "Empname is:" + x.empname);

        }
        Console.WriteLine("\t");


    }
}
