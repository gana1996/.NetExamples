﻿////Example for Generic Collection

//using System;
//using System.Collections.Generic;


//    class Employee
//    {
//    static void Main(string[] args)
//    {

//        Stack<string> empStack = new Stack<string>();
//        empStack.Push("RAHUL");
//        empStack.Push("Monisha");
//        empStack.Push("Shanmukh");
//        empStack.Push("Zehra");
//        empStack.Push("Suresh");
//        empStack.Push("Karunakar");
//        empStack.Push("Oshika");

//        PrintEmpNames(empStack);
//        Console.WriteLine("*********************");
//        Console.WriteLine("\nTop Element in Stack is:"+empStack.Peek());
//        Console.WriteLine("Remove top element from Stack:"+empStack.Pop());
//        PrintEmpNames(empStack);

//    }

//    public static void PrintEmpNames(Stack<string> s)
//    {
//        foreach(string x in s)
//        {
//            Console.WriteLine(x);
//        }
//    }
//    }
