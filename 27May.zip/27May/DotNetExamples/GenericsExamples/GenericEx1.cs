﻿////Example for limitation of Collection
//using System;
//using System.Collections;


//class GenericEx1
//{
//    static void Main(string[] args)
//    {
//        private ArrayList alStrings;
//    public GenericEx1()
//    {
//        alStrings = new ArrayList();
//    }


//    public void AddData()
//    {
//        alStrings.Add("ASP");
//        alStrings.Add("SAP");
//        alStrings.Add("ADO");
//        alStrings.Add(10);
//    }

//    public void Display()
//    {
//        foreach (string x in alStrings)
//        {
//            Console.WriteLine(x);
//        }
//    }
//}
//}


