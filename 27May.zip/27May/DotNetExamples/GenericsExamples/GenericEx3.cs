﻿////Example for Generic method 
//using System;


//    class Swapping
//    {
//    public void Swap<T>(ref T num1, ref T num2)
//    {
//        T temp;
//        temp = num1;
//        num1 = num2;
//        num2 = temp;
//    }
//    }
//class  MainClass
//{
//    static void Main(string[] args)
//    {
//        int num1 = 10;
//        int num2 = 20;
//        Console.WriteLine("Values before Swapping:"+num1+" "+num2);
//        Swapping sw = new Swapping();
//        sw.Swap<int>(ref num1, ref num2);
//        Console.WriteLine("Values after Swapping:"+num1+" "+num2);

    
//             string str1 = "Accenture";
//            string str2="iDC";
//        Console.WriteLine("Values before Swapping:" + str1 + " " + str2);
//        Swapping sw1 = new Swapping();
//        sw1.Swap<string>(ref str1, ref str2);
//        Console.WriteLine("Values before Swapping:" + str1 + " " + str2);
//    }
//}
