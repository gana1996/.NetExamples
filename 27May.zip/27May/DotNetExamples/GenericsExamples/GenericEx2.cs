﻿////Example for Geeric Class

//using System;
//using System.Collections.Generic;

//    class MyClass<T>
//    {
//    public T x;
//    public void PrintValues(T y)
//    {
//        Console.WriteLine("x="+x);
//        Console.WriteLine("y="+y);
//    }

//    public T printAdd(T x, T y)
//    {
//        dynamic a = x;
//        dynamic b = y;
//        return a + b;
//    }

    
//}

//class MainClass
//{
//    static void Main(string[] args)
//    {
//       MyClass<int> intRef = new MyClass<int>();
//        intRef.x = 10;
//        intRef.PrintValues(20);
//        Console.WriteLine("IntegeR Add="+intRef.printAdd(10,20));
//        Console.WriteLine("*****************************");
 
//        MyClass<string> strRef = new MyClass<string>();
//        strRef.x = "Accenture";
//        strRef.PrintValues("iDC");
//        Console.WriteLine("String is"+strRef.printAdd("Hey"," Accenturite"));
//        Console.WriteLine("******************");

//        MyClass<double> doubleRef = new MyClass<double>();
//        doubleRef.x = 10.75;
//        doubleRef.PrintValues(100.50);
//        Console.WriteLine("Daouble is"+doubleRef.printAdd(10.75,100.50));
//    }
//}