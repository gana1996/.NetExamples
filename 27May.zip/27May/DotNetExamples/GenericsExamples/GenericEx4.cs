﻿////Example for Generic Collection
//using System;
//using System.Collections.Generic;


//    class GenericEx4
//    {
//    static List<T>PrintList<T>(T first,T second)
//    {
//        List<T> myList = new List<T>();
//        myList.Add(first);
//        myList.Add(second);
//        return myList;
//    }

//    static void Main(string[] args)
//    {
//        List<string> slist = PrintList<string>("HDC", "PDC");
//        foreach(string x in slist)
//        {
//            Console.WriteLine(x);
//        }
//        Console.WriteLine("******************");
//        List<int> ilist = PrintList<int>(10, 20);
//        foreach(int x in ilist)
//        {

//            Console.WriteLine(x);
//        }
//    }
//    }

