﻿////Example to print a message
//using System;
//using A = System.Console;   //alias


//namespace LanguageFundamentals
//{
//	class LFExample1
//	{
//		static void Main(string[] args)
//		{
//			//Console.WriteLine("Welcome to Accenture");
//			A.WriteLine("Welcome to Accenture");  // gives linespace
//			A.Write("HDC2, Waverock Building"); //don't give linespace
//			A.WriteLine("Nanakramguda");
//			A.Write("Hyderabad");
//		}
//	}
//}
