﻿//using System;

//	class LFExample4
//	{
//	static void Main(string[] args)
//	{
//		int num = 10;
//		object obj1 = num;    //Implicit Type casting(Boxing)
//		Console.WriteLine(num);
//		Console.WriteLine(obj1);

//		int num1 = 20;
//		object obj2 = num1;
//		int num2 = (int)obj2;
//		Console.WriteLine(num2);   //Explicit Type Casting(Unboxing)
//  	}
//	}

