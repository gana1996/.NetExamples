﻿////Example for Switch
//using System;


//class LFExample7
//{
//	static void Main(string[] args)
//	{
//		char ch = 'e';
//		switch(ch)
//		{
//			//case 'a':Console.WriteLine("Vowel")  //this gives an error
//			case 'a':
//			case 'e':
//			case 'i':
//			case 'o':
//			case 'u': Console.WriteLine("Vowel");
//				break;
//			default: Console.WriteLine("Consonant");
//				break;
			
//		}
//	}
//}