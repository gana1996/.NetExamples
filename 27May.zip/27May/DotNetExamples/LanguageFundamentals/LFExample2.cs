﻿////Example for namespace
//using System;
//namespace ns1
//{
//	class Accenture
//	{
//		public void PrintMessage()
//		{
//			Console.WriteLine("Welcome to HDC1");
//		}
//	}
//}

//namespace ns2
//{
//	class Accenture
//	{
//		public void PrintMessage()
//		{
//			Console.WriteLine("Welcome to HDC2");
//		}
//	}
//}

//class MainClass
//{
//		static void Main(string[] args)
//		{
//			ns1.Accenture a1 = new ns1.Accenture();
//			a1.PrintMessage();
//			ns2.Accenture a2 = new ns2.Accenture();
//			a2.PrintMessage();
//		}
//}