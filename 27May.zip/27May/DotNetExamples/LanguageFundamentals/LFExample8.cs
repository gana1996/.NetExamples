﻿//Example for Arithematic Operations
using System;

class LFExample8
{
	static void Main(string[] args)
	{
		Console.WriteLine("Enter two numbers");
		int x = int.Parse(Console.ReadLine());
		int y = int.Parse(Console.ReadLine());
		Console.WriteLine("Sum is:" + (x + y));
		Console.WriteLine("Sub is:" + (x - y));
		Console.WriteLine("Multiplication is:" + (x * y));
		Console.WriteLine("Div is:" + (x /y));
		Console.WriteLine("Modulo is:" + (x % y));
	}
	

}

