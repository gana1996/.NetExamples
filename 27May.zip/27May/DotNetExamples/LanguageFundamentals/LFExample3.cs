﻿////Example Type Casting
//using System;

//class LFExample3
//	{
//	static void Main(string[] args)
//	{
//		int x = 10;
//		double y = x; //Implicit Type Casting
//		Console.WriteLine("y=" + y) ;

//		char ch = 'a';
//		int number = ch; //	Implicit Type Casting
//		Console.WriteLine("number="+number);

//		int m = 98;
//		char c = (char)m;  //Explicit Type Casting
//		Console.WriteLine("c="+c);
//	}
//	}

