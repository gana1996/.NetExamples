﻿////Example for enum
//using System;

//enum DaysOfWeek
//{
//	Monday,Tuesday,Wednesday,Thursday=20,Friday,Saturday,Sunday
//}

//class LFExample6
//{
//	static void Main(string[] args)
//	{
//		//DaysOfWeek today = DaysOfWeek.Thursday;
//		DaysOfWeek today = DaysOfWeek.Sunday;
//		DaysOfWeek today2 = DaysOfWeek.Friday;
//		Console.WriteLine((int)today2);
//		Console.WriteLine(today);
//		Console.WriteLine((int)today);
//		DaysOfWeek today1 = (DaysOfWeek)3;
//		Console.WriteLine(today1);


//		//if(today==DaysOfWeek.Sunday||today==DaysOfWeek.Saturday)
//			if (today == DaysOfWeek.Sunday || today == DaysOfWeek.Saturday)
//			{
//			Console.WriteLine("Holiday");
//		}
//		else
//		{
//			Console.WriteLine("Working Day");
//		}
//	}
	
//}
