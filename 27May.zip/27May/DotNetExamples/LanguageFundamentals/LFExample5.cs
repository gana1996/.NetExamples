﻿//using System;

//	struct Employee
//	{
//	public int empNo;
//	public string empName;
//	public double salary;
//	public string city;

//	public void PrintEmpDetails()
//	{
//		Console.WriteLine("Employee No:"+empNo);
//		Console.WriteLine("Employee Name:"+empName);
//		Console.WriteLine("Employee Salary:"+salary);
//		Console.WriteLine("Employee City:"+city);
//	}

//	class MainClass
//	{
//		static void Main(string[] args)
//		{
//			Employee e1;
//			e1.empNo = 1001;
//			e1.empName = "Gana";
//			e1.salary=500000;
//			e1.city = "Mumbai";
//			e1.PrintEmpDetails();

//			Employee e2;
//			e2.empNo = 1001;
//			e2.empName = "Rahul";
//			e2.salary = 700000;
//			e2.city = "Pune";
//			e2.PrintEmpDetails();
			
//		}
//	}
//	}

