﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.Tests
{
    [TestClass()]
    public class CalculationsTests
    {
        static Calculations c1 = null;

        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testcontext)
        {
            c1 = new Calculations();
        }
        [ClassCleanup]
        public static void MyClassCleanUp()
        {
            c1 = null;
        }

        [TestMethod()]
        public void PrintSumTest()
        {
            int num1 = 10;
            int num2 = 20;
            int expected = 30;
            int actual = c1.PrintSum(num1, num2);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void PrintProductTest()
        {
            int num1 = 20;
            int num2 = 10;
            int notexpected = 100;
            int actual = c1.PrintProduct(num1, num2);
            Assert.AreNotEqual(notexpected, actual);

        }

        [TestMethod()]
        public void PrintSubtractionTest()
        {
            int num1 = 20;
            int num2 = 10;
            int expected = 10;
            int actual = c1.PrintSubtraction(num1, num2);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void PrintDivisionTest()
        {
            int num1 = 20;
            int num2 = 5;
            try
            {

                c1.PrintDivision(num1, num2);

            }
            catch (DivideByZeroException)
            {
                Assert.Fail("Exception: Number cannot be divided by Zero");
            }
        }
        [TestMethod()]
        public void StringSameTest()
        {
            string expected = "accenture";
            string actual = "accenture";
            Assert.AreSame(expected, actual);//it will pass bcz expected and actual are reference types and both contain same strings
        }
        [TestMethod()]
        public void IntegerSameTest()
        {
            int notExpected = 10;
            int actual = 10;
            Assert.AreNotSame(notExpected, actual);//it will pass bcz notexpected and actual are not reference types even though they contain same values

        }
        [TestMethod()]
        public void ReferenceTest1()
        {
            Calculations c2 = null;
            Assert.IsNull(c2);
        }

        [TestMethod()]
        public void ReferenceTest2()
        {
            
            Assert.IsNotNull(c1);
        }

        public static CalculationsTests ct = null;
        public static CalculationsTests GetInstance()
        {
            if(ct==null)
            {
                ct = new CalculationsTests();
            }
            return ct;
        }

        [TestMethod()]
        public void ReferenceTest3()
        {
            CalculationsTests ct1 = CalculationsTests.GetInstance();
            CalculationsTests ct2 = CalculationsTests.GetInstance();
            Assert.IsTrue(ct1==ct2);//it will pass bcz ct1 and ct2 are referringg to same object
        }

        [TestMethod()]
        public void ReferenceTest4()
        {
            CalculationsTests ct1 = CalculationsTests.GetInstance();
            CalculationsTests ct2 = CalculationsTests.GetInstance();
            Assert.IsFalse(ct1 != ct2);//it will pass bcz ct1 and ct2 are referringg to same object
        }
    }
}