﻿////Example for LINQ to objects
//using System;
//using System.Linq;

//    class LinqEx2
//    {
//    static void Main(string[] args)
//    {
//        char[] array1 = { 'b', 's', 'e', 'q', 'o','u','g' };
//        var vowels = from x in array1
//                     where x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u'
//                     select x;
//        foreach(char ch in vowels)
//        {
//            Console.WriteLine(ch);
//        }
//        Console.Read();
//    }
//    }

