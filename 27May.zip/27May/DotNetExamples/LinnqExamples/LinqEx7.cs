﻿////Example for  LINQ to objects using LAMBDA
//using System;
//using System.Linq;

//    class LinqEx7
//    {
//    static void Main(string[] args)
//    {
//        int[] array1 = { 10, 20, 30, 40, 50 };
//        var result = array1.Where(x => x > 20);

//        foreach (int number in result)
//        {
//            Console.WriteLine(number);
//        }
//    }
//    }

