﻿////Example for LINQ to objects
//using System;
//using System.Linq;

//    class LinqEx4
//    {
//    static void Main(string[] args)
//    {
//        string[] locations = { "Delhi","Bangalore","Mumbai","Gurgoan","Bhubaneshwar","Hyderabad","Chennai","Pune"};
//        var result = from x in locations
//                     group x
//                     by x.Substring(0, 1)
//                     into mygroup
//                     orderby mygroup.Key descending
//                     select mygroup;

//        foreach(var s1 in result)
//        {
//            Console.WriteLine(s1.Key);
//            foreach(var s2 in s1)
//            {
//                Console.WriteLine( " "+s2);
//            }
//        }
//    }
//    }

