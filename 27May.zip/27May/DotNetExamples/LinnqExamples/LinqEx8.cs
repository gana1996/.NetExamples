﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace LinnqExamples
//{
//    class MyClass
//    {
//        AccentureDataContext ad = null;
//        public MyClass()
//        {
//            ad = new AccentureDataContext();

//        }
//        public void  DisplayDeptDetails()
//        {
//            var result = from x in ad.depts
//                         select x;
//            foreach (dept y in result)
//            {
//                Console.WriteLine(y.deptno+"\t\t"+y.dname+"\t\t"+y.location);
//            }
//        }

//        public dept DisplayDeptDetails(int dno)
//        {
//            dept d1 = null;
//            var result = from x in ad.depts
//                         where x.deptno == dno
//                         select x;
//            d1 = result.First();
//            Console.WriteLine(d1.deptno+"\t\t"+d1.dname+"\t\t"+d1.location);
//            return d1;
//        }

//        public int InsertDeptRecords(int dno,string dname,string loc)
//        {
//            dept d1 = new dept
//            {
//                deptno = dno,
//                dname = dname,
//                location = loc
//            };
//            ad.depts.InsertOnSubmit(d1);//to insert record into datacontext
//            ad.SubmitChanges();// to commit records into db
//            Console.WriteLine("Record inserted");
//            DisplayDeptDetails(dno);
//            return d1.deptno;
//        }

//        public bool UpdateDeptRecords(int dno,string dname,string loc)
//        {
//            dept d1 = DisplayDeptDetails(dno);
//            d1.deptno = dno;
//                d1.dname = dname;
//                d1.location = loc;
//            ad.SubmitChanges();
//            Console.WriteLine("Record Updated");
//            DisplayDeptDetails(dno);
//            return true;
//        }


//        public bool DeleteDeptRecord(int dno)
//        {
//            dept d1 = DisplayDeptDetails(dno);
//            ad.depts.DeleteOnSubmit(d1);
//            ad.SubmitChanges();
//            Console.WriteLine("Record deleted");
//            DisplayDeptDetails();
//            return true;
//        }

//        static void Main(string[] args)
//        {
//            MyClass m = new MyClass();
//            m.DisplayDeptDetails();
//            m.DisplayDeptDetails(10);
//           m.InsertDeptRecords(80,"IT","Mumbai");
//          //  m.UpdateDeptRecords(80,"IT","Mumbai");
//            m.DeleteDeptRecord(80);

//        }

//    }
//}
