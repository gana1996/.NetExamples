﻿//Example for  LINQ to objects
//using System;
//using System.Linq;


//    class LinqEx3
//    {
//    static void Main(string[] args)
//    {
//        string[] locations = { "Mumbai", "Hyderabad", "Kolkata", "Chennai", "Pune" };
//        var result = from x in locations
//                     where x.Length > 5
//                     orderby x ascending
//                     select x;

//        foreach(string s in result)
//        {
//            Console.WriteLine(s);
//        }
//    }
//    }

