﻿////Example for LINQ to objects Joins
//using System;
//using System.Linq;

//    class Employee
//    {
//    public int EmpNo { get; set; }
//    public string EmpName { get; set; }
//    }


//class Department
//{
//    public int EmpNo { get; set;}
//    public string DeptName { get; set; }
//}

//class MainClass
//{
//    static void Main(string[] args)
//    {
//        var emps = new Employee[]
//           {
//        new Employee{ EmpNo=1001,EmpName="Sai"},
//        new Employee{ EmpNo=1002,EmpName="Sai babu"},
//        new Employee{ EmpNo=1003,EmpName="Sai ram"},
//        new Employee{ EmpNo=1004,EmpName="Sai krish"},
//           };


//        var depts = new Department[]
//          {
//        new Department{ EmpNo=1004,DeptName="CSE"},
//        new Department{ EmpNo=1003,DeptName="ECE"},
//        new Department{ EmpNo=1002,DeptName="MEC"},
//        new Department{ EmpNo=1001,DeptName="EEE"},

//          };

//        var result = from e in emps
//                     join d in depts on e.EmpNo equals d.EmpNo
//                     select new { e.EmpName, d.DeptName };

//        foreach(var x in result)
//        {
//            Console.WriteLine(x.EmpName+"  works for  "+x.DeptName);
//        }
//    }
   
//}
