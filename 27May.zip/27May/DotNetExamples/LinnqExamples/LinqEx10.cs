﻿////Creating XML file using  LINQ
//using System;
//using System.Xml.Linq;

//class LinqEx10
//{
//    static void Main(string[] args)
//    {
//        XDocument document = new XDocument
//        (
//            new XDeclaration("1.0", "utf-8", "yes"),
//            new XComment("Employee xml"),
//            new XElement("Employees",
//            new XElement("Employee", new XAttribute("id", 1),
//            new XElement("Name", "Vivek"),
//             new XElement("Age", "35"),
//            new XElement("Job", "Manager")
//        ),

//            new XElement("Employee", new XAttribute("id", 2),
//            new XElement("Name", "Gummadi"),
//             new XElement("Age", "45"),
//            new XElement("Job", "Asst. Manager")
//        ),

//          new XElement("Employee", new XAttribute("id", 3),
//            new XElement("Name", "Rammadi"),
//             new XElement("Age", "25"),
//            new XElement("Job", "Asst. G Manager")
//        )
//        )
//        );

//        document.Save(@"C:\27MayExamples\Employee1.xml");
//        Console.WriteLine(XML document created successfully");
//    }
//}