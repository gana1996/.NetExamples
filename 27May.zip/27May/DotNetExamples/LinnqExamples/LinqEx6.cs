﻿////Example for  Linq with Lambda Expressions
//using System;
//using System.Linq;


//    class LinqEx6
//    {
//    static void Main(string[] args)
//    {
//        string[] accenture = { "MDC", "HDC", "CDC", "PDC", "BDC" };

//        var result = accenture.Select(x => x);
//        foreach(string s in result)
//        {
//            Console.WriteLine(s);
//        }
//    }
//    }

