﻿////Example for Linq to Dataset
//using System;
//using System.Linq;
//using System.Data.SqlClient;
//using System.Data;
//using System.Collections.Generic;


//    class MyClass
//    {
//    static void Main(string[] args)
//    {
//        SqlConnection con = new SqlConnection("server=(local);database=Apr19;integrated security=true");
//        SqlCommand cmd = new SqlCommand("select * from dept;select * from emp", con);
//        SqlDataAdapter sda = new SqlDataAdapter(cmd);
//        DataSet ds = new DataSet();

//        sda.Fill(ds);


//        var query1 = from x in ds.Tables[0].AsEnumerable()
//                     select x;

//        List<DataRow> result1 = query1.ToList();


//        var query2 = from x in ds.Tables[1].AsEnumerable()
//                     select x;

//        List<DataRow> result2 = query2.ToList();

//        Console.WriteLine("************Dept Table*************");
//        foreach(DataRow n in result1)
//        {
//            Console.WriteLine(n["deptno"]+"\t\t"+n["dname"]+"\t\t"+n["location"]);
//        }

//        Console.WriteLine("************Emp Table*************");
//        foreach (DataRow n in result2)
//        {
//            Console.WriteLine(n["empno"] + "\t\t" + n["ename"]+"\t\t" + n["sal"]);
//        }
//    }
//    }

