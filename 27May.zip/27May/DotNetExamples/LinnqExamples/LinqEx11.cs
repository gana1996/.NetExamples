﻿//Querying data from XML
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;


    class LinqEx11
    {
    static void Main(string[] args)
    {
        var names = (from x in XDocument.Load(@"C:\27MayExamples\Employee1.xml").Descendants("Employee")
                     where int.Parse(x.Element("Age").Value) < 40
                     select x.Element("Name").Value).ToList();
        foreach(string y in names)
        {
            Console.WriteLine(y);
        }
    }
    }

