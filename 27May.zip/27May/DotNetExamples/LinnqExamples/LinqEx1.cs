﻿////Example for LINQ to objects
//using System;
//using System.Linq;


//class LinqEx1
//{
//    static void Main(string[] args)
//    {
//        int[] array1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };//obtaining datasource
//        var result = from x in array1                    // Creating the query
//                     where (x % 2) == 0
//                     select x;
//        foreach(int num in result)                      // Executing the query
//        {
//            Console.WriteLine(num);
//        }
//        Console.Read();
//    }
//}
