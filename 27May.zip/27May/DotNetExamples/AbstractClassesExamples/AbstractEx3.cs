﻿////Example for sealed class
//using System;
//sealed class Employee
//{
//	protected int EmpId;
//	string EmpName;

//	public Employee()
//	{
//		EmpId = 1001;
//		EmpName="Vivek"
//	}

//	public void PrintEmpDetails()
//	{
//		Console.WriteLine("Empid:"+EmpId);
//		Console.WriteLine("EmpName:"+EmpName);
//	}
//}

//class Trainer:Employee
//{
//	public void PrintEmpDetails()
//	{
//		Console.WriteLine("Empid:" + EmpId);
//		Console.WriteLine("EmpName:" + EmpName);
//	}
//}