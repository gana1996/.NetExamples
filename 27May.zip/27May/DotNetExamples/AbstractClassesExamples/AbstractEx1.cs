﻿////Example for Abstract Class
//using System;
//abstract class Accenture
//{
//	public int EmpId { get; set; }
//	public string FirstName { get; set; }
//	public string LastName { get; set; }

//	public string PrintFullName()   //Concrete or Non-Abstract Method
//	{
//		return FirstName + " "+LastName;
//	}

//	public abstract double PrintMonthlySalary();//Abstract Method
//}
//class FullTimeEmployee:Accenture
//{
//	public double AnnualSalary { get; set; }

//	public override double PrintMonthlySalary()
//	{
//		return AnnualSalary / 12;
//	}
//}

//class ContractEmployee : Accenture
//{
//	public double TotalHoursWorked{get;set;}
//public double HourlyPay { get; set; }
//	public override double PrintMonthlySalary()
//	{
//		return TotalHoursWorked * HourlyPay;
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{

//		FullTimeEmployee fte = new FullTimeEmployee  //Object Initializer
//		{
//			EmpId = 1001,
//			FirstName = "Vivek",
//			LastName = "Nukala",
//			AnnualSalary = 60000
//		};

//		Console.WriteLine("EmpId:"+fte.EmpId);
//		Console.WriteLine("Employee FName:"+fte.PrintFullName());
//		Console.WriteLine("EmpSal:"+fte.PrintMonthlySalary());
//		Console.WriteLine("******************************");


//		ContractEmployee cte = new ContractEmployee
//		{
//			EmpId = 1001,
//			FirstName = "Sravya",
//			LastName = "Nukala",
//			TotalHoursWorked = 100,
//			HourlyPay=30
//		};
//		Console.WriteLine("Empid:"+cte.EmpId);
//		Console.WriteLine("EmpName:"+cte.PrintFullName());
//		Console.WriteLine("EmpSal:"+cte.PrintMonthlySalary());
//	}
//}