﻿//Example for Sealed Method
using System;
class Parent
{
	public virtual void PrintMessage()
	{
		Console.WriteLine("Welcome to Mumbai");
	}
}

class Child:Parent
{
	public sealed override void PrintMessage()
	{
		Console.WriteLine("Welcome to Mumbai");
	}
}

class GrandChild : Child
{
	//public sealed override void PrintMessage()// cannot override sealed method
}