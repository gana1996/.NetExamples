﻿////Example for Value type parameters
//using System;

//	class MethodEx2
//	{
//		public static void PrintValues(int x)
//	{
//		x *= x;
//		Console.WriteLine("x="+x);
//	}
//	static void Main(string[] args)
//	{
//		int x = 5;
//		Console.WriteLine("x=" + x);
//		PrintValues(x);
//		Console.WriteLine("x="+x);
//	}
//	}
