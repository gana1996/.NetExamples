﻿////Example for Optional Parameters and Named arguments
//using System;

//	class MethodEx6
//	{
//	public static void PrintValues(int x=10,string str1="Accenture")
//	{
//		Console.WriteLine("x="+x);
//		Console.WriteLine("str1="+str1);
//	}
//	static void Main(string[] args)
//	{
//		PrintValues();
//		PrintValues(20);
//		//PrintValues("Hyderabad"); this doesn't work becoz without giving 1st param we cannot pass 2nd param
//		PrintValues(str1:"Hyderabad");//Named Arguments
//		PrintValues(str1: "Mumbai", x: 40);//Named Arguments
//	}
//	}
