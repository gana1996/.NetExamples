﻿//using System;

//class MethodsEx1
//{
//	public void PrintSum(int x, int y)
//	{
//		Console.WriteLine("Sum is" + (x + y));
//	}

//	public int PrintProduct(int x, int y)
//	{
//		return x * y;
//	}
//	public int PrintDivision(int x, int y)
//	{
//		return x / y;
//	}
//	public double PrintCircleArea(double radius)
//	{
//		return Math.PI * radius * radius;
//	}

//	static void Main(string[] args)
//	{
//		MethodsEx1 m1 = new MethodsEx1();
//		Console.WriteLine("Enter two numbers");
//		int num1= int.Parse(Console.ReadLine());
//		int num2= int.Parse(Console.ReadLine());
//		m1.PrintSum(num1,num2); //Actual Paramarameters while calling methods
//		Console.WriteLine("Product is"+m1.PrintProduct(num1,num2));
//		Console.WriteLine("Division is" + m1.PrintDivision(num1, num2));

//		Console.WriteLine("Enter circle radius");
//		int rad= int.Parse(Console.ReadLine());
//		Console.WriteLine("Circle area is" + m1.PrintCircleArea(rad));

//	}
//}
