﻿////Example for output parameters
//using System;

//	class MethodEx5
//	{
//	static void PrintResult(int num1,int num2,out int add,out int sub,out int prod)
//	{
//		add = num1 + num2;
//		sub = num1 - num2;
//		prod = num1 * num2;
//	}
//	static void Main(string[] args)
//	{
//		int num1 = 10, num2 = 5;
//		int total, subtraction, multiplication;
//		PrintResult(num1, num2, out total, out subtraction, out multiplication);
//		Console.WriteLine("Sum={0}\nSubtraction={1}\nMultiplication={2}",total,subtraction,multiplication);
//		//or
//		Console.WriteLine("Sum is:"+total);
//		Console.WriteLine("Subtraction is:"+subtraction);
//		Console.WriteLine("Multiplication is:"+multiplication);
//	}
//	}
