﻿////Example for Output type parameters
//using System;

//class MethodEx2
//{
//	public static void PrintValues(out int x) //out keyword is used
//	{
//		x = 10;
//		x *= x;
//		Console.WriteLine("x=" + x);
//	}
//	static void Main(string[] args)
//	{
//		int x = 5;
//		Console.WriteLine("x=" + x);
//		PrintValues(out x);
//		Console.WriteLine("x=" + x);
//	}
//}
