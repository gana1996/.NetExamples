﻿////Example for Reference type parameters
//using System;

//class MethodEx2
//{
//	public static void PrintValues(ref int x) //ref keyword is used
//	{
//		x *= x;
//		Console.WriteLine("x=" + x);
//	}
//	static void Main(string[] args)
//	{
//		int x = 5;
//		Console.WriteLine("x=" + x);
//		PrintValues(ref x);
//		Console.WriteLine("x=" + x);
//	}
//}
