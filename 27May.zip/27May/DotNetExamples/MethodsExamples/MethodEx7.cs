﻿//Example for Parameter Arrays:
using System;

	class MethodEx7
	{
	public static void PrintArray1(params int[] array1)
	{
		for(int i=0;i<array1.Length;i++)
		{
			Console.WriteLine(array1[i]);
		}

	}

	public static void PrintArray2(params object[] array1)
	{
		for (int i = 0; i < array1.Length; i++)
		{
			Console.WriteLine(array1[i]);
		}

	}

	static void Main(string[] args)
	{
		PrintArray1(1, 2, 3);
		PrintArray2(1, 'a', "accenture");
		int[] array2 = new int[] { 10, 20, 30, 40, 50 };
		PrintArray1(array2);
	}
}
