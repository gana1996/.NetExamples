﻿////Example for Constructor Implementation
//using System;
//class MyClass
//{
//	int x, y;
//	public MyClass() : this(100)//Default
//	{
//		x = 10;
//		y = 20;
//		this.PrintValues();
//	}


//	public MyClass(int x)//Parameterized
//	{
//		this.x = x;
//		this.y = x;
//		this.PrintValues();

//	}

//	public MyClass(int x, int y) : this()//Overloaded
//	{
//		this.x = x;
//		this.y = y;
//		this.PrintValues();
//	}
//	public void PrintValues()
//	{
//		Console.WriteLine("x=" + x);
//		Console.WriteLine("y=" + y);
//	}

//	static void Main(string[] args)
//	{
//		new MyClass(1000, 2000);
//		Console.Read();
//	}
//}