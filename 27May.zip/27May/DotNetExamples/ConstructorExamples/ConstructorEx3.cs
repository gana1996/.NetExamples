﻿//Example for Static Constructor
using System;

class Test
{
	public static int count = 0;
		static Test()
	{
		count++;
	}

}
class MainClass
{
	static void Main(string[] args)
	{
		Console.WriteLine("count="+Test.count); //static will be called only when we call for first time
		Console.WriteLine("count=" + Test.count);
	}
}