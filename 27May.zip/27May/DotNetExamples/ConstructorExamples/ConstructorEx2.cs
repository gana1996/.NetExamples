﻿////Example for Static constructor
//using System;
//class Test
//{
//	public Test()
//	{
//		Console.WriteLine("Instance Constructor");
//	}
//	static Test()
//	{
//		Console.WriteLine("Static Constructor");
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{
//		new Test();
//		new Test();
//	}
//}