﻿////Example for accessing the data using Stored Procedures
//using System;
//using System.Data;
//using System.Data.SqlClient;

//class ADOEx3
//{

//    string cs = "server=(local);database=Apr19;integrated security=true;";
//    SqlConnection con = null;
//    SqlCommand cmd = null;
//    SqlDataReader reader = null;


//    public void DisplayDepRecords()
//    {
//        try
//        {
//            con = new SqlConnection(cs);
//            con.Open();
//            cmd = new SqlCommand("spDeptFetch", con);
//            cmd.CommandType = CommandType.StoredProcedure;
//            reader = cmd.ExecuteReader();
//            while (reader.Read())
//            {
//                Console.WriteLine(reader["deptno"] + "\t\t" + reader["dname"] + "\t\t" + reader["location"]);
//            }
//        }
//        catch (SqlException se)
//        {

//            Console.WriteLine(se.Message);
//        }

//        catch (Exception e) { Console.WriteLine(e.Message); }

//        finally
//        {

//            if (reader != null)
//            {
//                reader.Dispose();
//            }
//            if (cmd != null)
//            {
//                cmd.Dispose();
//            }
//            if (con != null)
//            {

//                con.Close();
//            }
//        }
//    }

//    //------------------------------iNSERTING RECORDS-----------------------------------------
//    public void InsertDepRecords(int dno,string name,string loc)
//    {
//        try
//        {
//            con = new SqlConnection(cs);
//            con.Open();
//            cmd = new SqlCommand("spDeptInsert", con);
//            cmd.CommandType = CommandType.StoredProcedure;
//            cmd.Parameters.AddWithValue("@dno", dno);
//            cmd.Parameters.AddWithValue("@name", name);
//            cmd.Parameters.AddWithValue("@loc", loc);
//            cmd.ExecuteNonQuery();
//            Console.WriteLine("Record inserted");
//            DisplayDepRecords();
            
//        }
//        catch (SqlException se)
//        {

//            Console.WriteLine(se.Message);
//        }

//        catch (Exception e) { Console.WriteLine(e.Message); }

//        finally
//        {

           
//            if (cmd != null)
//            {
//                cmd.Dispose();
//            }
//            if (con != null)
//            {

//                con.Close();
//            }
//        }
//    }

//    static void Main(string[] args)
//    {
//        ADOEx3 a3 = new ADOEx3();
//        a3.DisplayDepRecords();
//        a3.InsertDepRecords(60,"IT","Chennai");
//    }
//}