﻿
using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

class ADOEx4
{
    string cs = "server=(local);database=Apr19;integrated security=true";
    public void DisplayDeptRecords()
    {
        try
        {
            DataSet ds = SqlHelper.ExecuteDataset(cs, CommandType.StoredProcedure, "spDeptFetch");
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                Console.WriteLine(row["deptno"] + "\t\t" + row["dname"] + "\t\t" + row["location"]);
            }

        }
        catch (SqlException se)
        {

            Console.WriteLine(se.Message);
        }

        catch (Exception e) { Console.WriteLine(e.Message); }

    }

    //-----------------------------------INSERTING RECORDS----------------------------------------
    public void InsertDeptRecords(int dno, string name, string loc)
    {
        try
        {
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@dno", SqlDbType.Int, 4);
            param[0].Value = dno;
            param[1] = new SqlParameter("@name", SqlDbType.VarChar, 20);
            param[1].Value = name;
            param[2] = new SqlParameter("@loc", SqlDbType.VarChar, 20);
            param[2].Value = loc;
            DataSet ds = SqlHelper.ExecuteDataset(cs, CommandType.StoredProcedure, "spDeptInsert", param);
            Console.WriteLine("Record Inserted");
            DisplayDeptRecords();
        }
        catch (SqlException se)
        {

            Console.WriteLine(se.Message);
        }

        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }

    static void Main(string[] args)
    {
        ADOEx4 a4 = new ADOEx4();
        a4.DisplayDeptRecords();
        a4.InsertDeptRecords(70, "Finance", "Pune");
    }
}

