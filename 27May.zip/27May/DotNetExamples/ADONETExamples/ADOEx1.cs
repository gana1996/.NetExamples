﻿////Example for SQL Data Reader
//using System;
//using System.Data.SqlClient;

//class ADOEx1
//{
//    string cs = "server=(local);database=Apr19;integrated security=true";



    
//    /// -----------------------------------------------------Displaying Records--------------------------------------------------------
  

//    public void DisplayDeptRecords()
//    {
//        using (SqlConnection con = new SqlConnection(cs))
//        {
//            //   SqlConnection con = new SqlConnection("server=(local);database=Apr19;integrated security=true");
//            con.Open();
//            // SqlCommand cmd = new SqlCommand("select * from dept", con);
//            using (SqlCommand cmd = new SqlCommand("select * from dept", con))
//            {
//                SqlDataReader reader = cmd.ExecuteReader();
//                while (reader.Read())
//                {
//                    Console.WriteLine(reader["deptno"] + "\t\t" + reader["dname"] + "\t\t" + reader["location"]);
//                }
//            }

//            //  cmd.Dispose();
//            //   con.Close();
//        }
//    }



    
//    /// ------------------------------------------------------Inserting data----------------------------------------------
   

//    public void InsertDeptRecords(int dno,string name,string loc)
//        {
//            string query = "insert into dept(deptno,dname,location)values(@dno,@name,@loc)";
//            using (SqlConnection con = new SqlConnection(cs))
//            {
//                //   SqlConnection con = new SqlConnection("server=(local);database=Apr19;integrated security=true");
//                con.Open();
//                // SqlCommand cmd = new SqlCommand("select * from dept", con);
//                using (SqlCommand cmd = new SqlCommand(query, con))
//                {
//                    cmd.Parameters.AddWithValue("@dno", dno);
//                    cmd.Parameters.AddWithValue("@name", name);
//                    cmd.Parameters.AddWithValue("@loc", loc);
//                    cmd.ExecuteNonQuery();
//                Console.WriteLine("Record Inserted");
//                }
//            }
//        }


  
//    /// ----------------------------------------------Updating Records--------------------------------------------------
    
//    public void UpdateDeptRecords(int dno, string name, string loc)
//    {
//        string query = "update dept set dname=@name,location=@loc where deptno=@dno ";
//        using (SqlConnection con = new SqlConnection(cs))
//        {
            
//            con.Open();
         
//            using (SqlCommand cmd = new SqlCommand(query, con))
//            {
//                cmd.Parameters.AddWithValue("@dno", dno);
//                cmd.Parameters.AddWithValue("@name", name);
//                cmd.Parameters.AddWithValue("@loc", loc);
//                cmd.ExecuteNonQuery();
//                Console.WriteLine("Record Updated");
//            }
//        }
//    }


//    /// ------------------------------------------Deleting Records----------------------------------------------------------
 
//    public void DeleteDeptRecords(int dno)
//    {
//        string query = "delete from dept where deptno=@dno ";
//        using (SqlConnection con = new SqlConnection(cs))
//        {

//            con.Open();

//            using (SqlCommand cmd = new SqlCommand(query, con))
//            {
//                cmd.Parameters.AddWithValue("@dno", dno);
//                cmd.ExecuteNonQuery();
//                Console.WriteLine("Record Deleted");
//            }
//        }
//    }



//    static void Main(string[] args)
//    {
//        ADOEx1 a1 = new ADOEx1();
//        a1.DisplayDeptRecords();
//     //       a1.InsertDeptRecords(50,"F&S","Gurgoan");
//            a1.DisplayDeptRecords();
//        a1.UpdateDeptRecords(50,"Travel","Mumbai");
//        a1.DisplayDeptRecords();
//        a1.DeleteDeptRecords(50);
//             a1.DisplayDeptRecords();
//    }
//}