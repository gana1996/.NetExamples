﻿////Example for DataAdapter and DataSet
//using System;
//using System.Data;
//using System.Data.SqlClient;

//class ADOEx2
//{

//    string cs = "server=(local);database=Apr19;integrated security=true;";
//    SqlConnection con = null;
//    SqlCommand cmd = null;
//    SqlDataAdapter sda = null;


//    public void DisplayDepRecords()
//    {

//        try
//        {
//            string query = "select * from dept";
//            con = new SqlConnection(cs);
//            cmd = new SqlCommand(query, con);
//            sda = new SqlDataAdapter(cmd);
//            DataSet ds = new DataSet();
//            sda.Fill(ds, "dept");


//            foreach (DataRow x in ds.Tables["dept"].Rows)
//            {

//                Console.WriteLine(x["deptno"] + "\t\t" + x["dname"] + "\t\t" + x["location"]);

//            }
//        }
//        catch (SqlException se)
//        {

//            Console.WriteLine(se.Message);
//        }

//        catch (Exception e) { Console.WriteLine(e.Message); }

//        finally
//        {

//            if (sda != null)
//            {
//                sda.Dispose();
//            }
//            if (cmd != null)
//            {
//                cmd.Dispose();
//            }
//            if (con != null)
//            {

//                con.Close();
//            }
//        }
//    }
//        //---------------------------------iNSERTING RECORDS----------------------------------------------
//        public void InsertDepRecords(int dno,string name,string loc)
//        {

//            try
//            {
//                string query = "insert into dept(deptno,dname,location)values(@dno,@name,@loc)";
//                con = new SqlConnection(cs);
//                cmd = new SqlCommand(query, con);
//            cmd.Parameters.AddWithValue("@dno", dno);
//            cmd.Parameters.AddWithValue("@name", name);
//            cmd.Parameters.AddWithValue("@loc", loc);
//                sda = new SqlDataAdapter(cmd);
//                DataSet ds = new DataSet();
//                sda.Fill(ds, "dept");
//            Console.WriteLine("Records Inserted Successfully");
//            DisplayDepRecords();
 
//            }
//            catch (SqlException se)
//            {

//                Console.WriteLine(se.Message);
//            }

//            catch (Exception e) { Console.WriteLine(e.Message); }

//            finally
//            {

//                if (sda != null)
//                {
//                    sda.Dispose();
//                }
//                if (cmd != null)
//                {
//                    cmd.Dispose();
//                }
//                if (con != null)
//                {

//                    con.Close();
//                }
//            }



//        }

//    //---------------------------------UPDATING RECORDS----------------------------------------------






//    static void Main(string[] args)
//    {
//        ADOEx2 a = new ADOEx2();
//        a.DisplayDepRecords();
//        a.InsertDepRecords(50, "Finance", "Mumbai");
//    }
//}
