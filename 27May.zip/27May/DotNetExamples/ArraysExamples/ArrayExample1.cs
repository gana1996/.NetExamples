﻿////Example for one dimension array
//using System;

//class ArrayExample1
//{
//	static void Main(string[] args)
//	{
//		int[] numbers = new int[3];//Declaration
//		numbers[0] = 100;//Initialization
//		numbers[1] = 200;
//		numbers[2] = 300;
//		int[] newNumbers = { 1, 2, 3 };//Declaration and Initialization

//		for(int i=0;i<numbers.Length;i++)
//		{
//			Console.WriteLine(numbers[i]);
//		}

//		numbers = newNumbers;
//		for(int i=0;i<numbers.Length;i++)
//		{
//			Console.WriteLine(numbers[i]);
//		}
//	}
	

//}