﻿using System;

class ArrayExample6
{
	static void Main(string[] args)
	{
		int[] array1 = new int[5] { 10, 20, 30, 40, 50 };

		foreach (int number in array1)
		{
			Console.WriteLine(number);
		}
		Console.Read();
	}
}
