﻿////Example for 2D array
//using System;

//class ArrayExample3
//{
//	static void Main(string[] args)
//	{
//		int[,] a = new int[3, 3];
//		Console.WriteLine("Enter elements into the array");
//		for(int i=0;i<3;i++)
//		{
//			for(int j=0;j<3;j++)
//			{
//				a[i, j] = int.Parse(Console.ReadLine());
//			}
//		}
//		Console.WriteLine("Enter elements into the array");
//		for(int i=0;i<3;i++)
//		{
//			for (int j = 0; j < 3; j++)
//			{
//				Console.Write(a[i, j] + "\t");
//			}
//			Console.WriteLine();
//		}
//	}
//}