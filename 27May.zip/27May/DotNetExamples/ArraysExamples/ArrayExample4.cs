﻿////Example for Jagged Arrays
//using System;

//class ArrayExample4
//{
//	static void Main(string[] args)
//	{
//		string[][] members = new string[3][];
//		members[0] = new string[2] { "Gana", "Sai" };
//		members[1] = new string[3] { "Gana", "Sai","Raj" };
//		members[2] = new string[4] { "Gana", "Vivek","Raj","Rahul" };
	
//	for(int i=0;i<members.Length;i++)  //this is members[0],members[1],members[2]
//		{
//			for(int j=0;j<members[i].Length;j++)  //this is for rows
//			{
//				Console.Write(members[i][j] + "\t");
//			}
//			Console.WriteLine();
//		}
//	}
//}