﻿//using System;

//class ArrayExample2
//{
//	static void Main(string[] args)
//	{
//		int[] array1 = new int[5];
//		int flag = 0;
//		Console.WriteLine("Enter elements into the array");
//		for (int i = 0; i < array1.Length; i++)
//		{
//			array1[i] = Convert.ToInt32(Console.ReadLine());
//		}

//		Console.WriteLine("Enter number to be searched");
//		int n = int.Parse(Console.ReadLine());
//		for (int i = 0; i < array1.Length; i++)
//		{
//			if (array1[i] == n)
//			{
//				flag = 1;
//				break;
//			}
			
//		}
//		if (flag == 1)
//		{
//			Console.WriteLine("Element found");
//		}
//		else
//		{
//			Console.WriteLine("Element not found");
//		}
//	}
//}
