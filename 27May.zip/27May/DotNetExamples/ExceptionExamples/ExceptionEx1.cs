﻿////Example for try,catch and finally blocks
//using System;

//class ExceptionEx1
//{
//	static void Main(string[] args)
//	{
//		try
//		{
//			Console.WriteLine("Enter x,y values");
//			int x = int.Parse(Console.ReadLine());
//			int y = int.Parse(Console.ReadLine());
//			Console.WriteLine("Division is"+(x/y));
//		}
//		catch(DivideByZeroException e)
//		{
//			Console.WriteLine("Number cannot be div by 0");
//			//Console.WriteLine(e.Message);
//			//Console.WriteLine(e.StackTrace);
//		}
//		finally
//		{
//			Console.WriteLine("Program execution is completed");
//		}
//	}
//}

