﻿using System;


class AgeException : ApplicationException
{
	public AgeException() : base()
	{

	}
	public AgeException(string message) : base(message)
	{

	}
}
class Employee
{
	private int empAge;
	public int EmpAge
	{
		set
		{
			if (value >= 20 && value <= 60)
			{
				empAge = value;
			}
			else
			{
				AgeException a1 = new AgeException("Age must between 20 and 60");
				throw a1;
			}
		}
		get { return empAge; }
	}


}

class MainClass
{
	static void Main(string[] args)
	{
		Employee e1 = new Employee();
		try
		{
			Console.WriteLine("Enter your age");
			e1.EmpAge = int.Parse(Console.ReadLine());
			Console.WriteLine("Emp age is" + e1.EmpAge);
		}
		catch (AgeException ex)
		{
			Console.WriteLine(ex.Message);
		}

	}
}