﻿////Example for try, catch and finally
//using System;
//using System.IO;
//	class ExceptionEx2
//	{ 
//	static void Main(string[] args)
//	{
//		StreamReader sr = null;
//		try
//		{
//			sr = new StreamReader(@"C:\27MayExamples\accenture.txt");
//			Console.WriteLine(sr.ReadToEnd());
//		}
//		catch(FileNotFoundException ex)
//		{
//			Console.WriteLine(ex.Message);
//		}
//		catch(Exception ex)
//		{
//			Console.WriteLine(ex.Message);
//		}
//		finally
//		{
//			if(sr!=null)
//			{
//				sr.Close();
//			}
//		}
//	}
//	}

