﻿////Example for nested try,catch
//using System;
//using System.IO;

//	class ExceptionEx3
//	{
//	static void Main(string[] args)
//	{
//		try
//		{
//			Console.WriteLine("Enter x,y values:");
//			int x = int.Parse(Console.ReadLine());
//			int y = int.Parse(Console.ReadLine());
//			Console.WriteLine("Division is:"+(x/y));
//			try
//			{
//				int[] array1 = new int[4]{ 10, 20, 30, 40 };
//				for(int i=0;i<=array1.Length;i++)
//				{
//					Console.WriteLine(array1[i]);
//				}
//			}
//			catch(IndexOutOfRangeException ex)
//			{
//				Console.WriteLine(ex.Message);
//			}
//		}
//		catch(DivideByZeroException ex)
//		{
//			Console.WriteLine(ex.Message);
//		}
//		catch (Exception ex)
//		{
//			Console.WriteLine(ex.Message);
//		}
//		finally
//		{
//			Console.WriteLine("Execute everytime");
//		}
//	}
//	}
