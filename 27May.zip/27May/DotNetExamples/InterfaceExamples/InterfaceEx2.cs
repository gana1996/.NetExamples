﻿////Example 
//using System;
//interface interface1
//{
//	void PrintMessage1();

//}

//interface interface2
//{
//	void PrintMessage2();

//}

//abstract class MyClass1:interface1,interface2
//{
//	public void PrintMessage1()
//	{
//		Console.WriteLine("PrintMessage1 is implemented");
//	}
//	public abstract void PrintMessage2();
//}
//class MyClass2:MyClass1
//{
//	public override void PrintMessage2()
//	{
//		Console.WriteLine("PrintMessage2 is implemented");
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{

//		MyClass2 m1 = new MyClass2();
//		m1.PrintMessage1();
//		m1.PrintMessage2();
//	}
//}