﻿//Example for interface
using System;

interface interface1
{
	void PrintMessage1();
}

interface interface2
{
	void PrintMessage2();
}

interface interface3:interface1,interface2
{
	void PrintMessage3();
}

abstract class MyClass1:interface3
{
	public void PrintMessage1()
	{
		Console.WriteLine("Welcome to HDC");
	}

	public void PrintMessage2()
	{
		Console.WriteLine("Welcome to MDC");
	}
	public abstract void PrintMessage3();

}

class MyClass2 : MyClass1
{
	public override void PrintMessage3()
	{
		Console.WriteLine("Welcome to BDC");
	}
}

class MainClass
{
	static void Main(string[] args)
	{
		interface3 i1 = new MyClass2();
		i1.PrintMessage1();
		i1.PrintMessage1();
		i1.PrintMessage3();

		//or

		MyClass2 m1 = new MyClass2();
		m1.PrintMessage1();
		m1.PrintMessage2();
		m1.PrintMessage3();
	}
}