﻿////Example for Interface
//using System;

//interface IShuttle
//{
//	void Register(string empName);
//	void UnRegister(string empName);
//}

//interface ICab
//{
//	void Register(string empName);
//	void UnRegister(string empName);
//}
//class Employee
//{
//	private int EmpId;
//	private string EmpName;

//	public int EmpId1 { get => EmpId; set => EmpId = value; }
//	public string EmpName1 { get => EmpName; set => EmpName = value; }


//	public Employee(int EmpId,string EmpName)
//	{
//		this.EmpId = EmpId;
//		this.EmpName = EmpName;
//	}

//	public void DisplayEmpDetails()
//	{
//		Console.WriteLine("EmpId"+EmpId);
//		Console.WriteLine("EmpName:"+EmpName);
//	}
//}

//class Trainer:Employee,IShuttle,ICab
//{
//	public Trainer(int EmpId,string EmpName):base(EmpId,EmpName)
//	{
		
//	}

//	void IShuttle.Register(string empName)
//	{
//		Console.WriteLine("Congratualations:"+empName+" You have successfully registered for shuttl");
//	}

//	void IShuttle.UnRegister(string empName)
//	{
//		Console.WriteLine( empName + " You have successfully unregistered for shuttl");
//	}

//	void ICab.Register(string empName)
//	{
//		Console.WriteLine("Congratualations:"+empName + " You have successfully registered forcab");
//	}

//	void ICab.UnRegister(string empName)
//	{
//		Console.WriteLine( empName + " You have successfully unregistered for cab");
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{
//		Trainer t1 = new Trainer(1001,"Vivek");
//		IShuttle shutObj = t1;
//		shutObj.Register(t1.EmpName1);
//		shutObj.UnRegister(t1.EmpName1);

//		ICab cabObj = t1;
//		cabObj.Register(t1.EmpName1);
//		cabObj.UnRegister(t1.EmpName1);
//	}
//}