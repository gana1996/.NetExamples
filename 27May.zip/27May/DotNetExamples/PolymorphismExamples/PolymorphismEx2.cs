﻿////Example for Method Oveerriding
//using System;
//class Employee
//{
//	private int empId;
//	private string empName;
//	public Employee(int empId, string empName)
//	{
//		this.empId = empId;
//		this.empName = empName;
//	}

//	public virtual void PrintEmpDetails()
//	{
//		Console.WriteLine("EmpId:" + empId);
//		Console.WriteLine("EmpName" + empName);

//	}
//}

//class Participant : Employee
//{
//	private double[] marks = new double[3];
//	public Participant(int empId, string empName, double[] marks) : base(empId, empName)
//	{
//		this.marks = marks;
//	}

//	public override void PrintEmpDetails()
//	{
//		base.PrintEmpDetails();
//		for (int i = 0; i < 3; i++)
//		{
//			Console.WriteLine("marks[" + i + "]=" + marks[i]);
//		}
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{
//		double[] marks = { 98, 99, 100 };
//		Employee e1 = new Employee(1001, "Rahul");
//		Console.WriteLine("************************************");

//		e1.PrintEmpDetails();
//		e1 = new Participant(1002, "Raj", marks); //Upcasting
//		e1.PrintEmpDetails();


//	}
//}