﻿////Example for Method Overloading
//using System;
//class MyClass
//{
//	public static int PrintSum(int x,int y)
//	{
//		return x + y;
//	}

//	public static int PrintSum(int x, int y,int z)
//	{
//		return x + y+z;
//	}
//	public static double PrintSum(double x,double y)
//	{
//		return x + y;
//	}
//	public static double PrintSum(int x, double y)
//	{
//		return x + y;
//	}
//	public static string PrintSum(string str1, string str2)
//	{
//		return str1 + str2;
//	}
//}

//class MainClass
//{
//	static void Main(string[] args)
//	{
//		Console.WriteLine("Print Sum(10,20):"+MyClass.PrintSum(10,20));
//		Console.WriteLine("Print Sum(10,20,30):" + MyClass.PrintSum(10, 20,30));
//		Console.WriteLine("Print Sum(10,20.50):" + MyClass.PrintSum(10, 20.5));
//		Console.WriteLine("Print Sum(10.20,20.20):" + MyClass.PrintSum(10.20, 20.20));
//		Console.WriteLine("Print Sum(accenture,IDC):" + MyClass.PrintSum("accenture", "IDC"));

//	}
//}