﻿////Example for Parallell for loop
//using System;
//using System.Threading.Tasks;

//class ParallellProgrammingEx5
//    {
//    static void Main(string[] args)
//    {
//        Console.WriteLine("**************for loop result*****************");
//        for(int i=1;i<=5;i++)
//        {
//            Console.Write(i+"\t");
//        }
//        Console.WriteLine("************Parallell for loop result*****************");
//        Parallel.For(1, 11, i =>
//          {
//              Console.WriteLine(i + "\t");
//          });

        
//    }
//    }

