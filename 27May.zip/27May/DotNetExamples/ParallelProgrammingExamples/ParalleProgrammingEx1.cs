﻿////Example for creating tasl
//using System;
//using System.Threading.Tasks;


//    class ParalleProgrammingEx1
//    {
//        static void Main(string[] args)
//        {
//        Action action1 = delegate
//          {
//              for (int i = 1; i <= 5; i++)
//              {
//                  Console.WriteLine("action1    " + i);
//              }
//          };
//        Action action2 = delegate
//        {
//            for (int i = 1; i <= 5; i++)
//            {
//                Console.WriteLine("action2    " + i);
//            }
//        };

//        Task t1 = new Task(action1);
//        Task t2 = new Task(action2);
//        t1.Start();
//        t2.Start();
//      Console.Read();
//    }
//    }

