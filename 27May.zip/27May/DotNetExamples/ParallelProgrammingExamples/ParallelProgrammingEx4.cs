﻿////Example for returning data from a TASK
//using System;
//using System.Threading.Tasks;
//using System.Collections.Generic;
//using System.Threading;

//class ParallelEx4
//{

//    static List<string> PrintData()
//    {

//        List<string> names = new List<string>();
//        names.Add("Mumbai");
//        names.Add("Hyderabad");
//        names.Add("Pune");
//        names.Add("Chennai");
//        return names;
//    }

//    static void Main(string[] args)
//    {
//        Task<List<string>> task1 = new Task<List<string>>(PrintData);
//        task1.Start();
//        Thread.Sleep(3000);
//        foreach (var x in task1.Result)
//        {

//            Console.WriteLine(x);

//        }
//    }

//}