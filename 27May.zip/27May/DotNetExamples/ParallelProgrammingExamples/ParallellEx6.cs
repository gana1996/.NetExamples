﻿//Example for Parallell for loop
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

class ParallellProgrammingEx6
{
    static void Main(string[] args)
    {
        Console.WriteLine("**************for loop result*****************");
        for (int i = 1; i <= 5; i++)
        {
            Console.Write(i + "\t");
        }
        Console.WriteLine("************Parallell for loop result*****************");
        List<int> numberList = new List<int> { 1, 2, 3, 4, 5 };
        Parallel.ForEach(numberList, i =>
        {
            Console.WriteLine(i + "\t");
        });


    }
}


