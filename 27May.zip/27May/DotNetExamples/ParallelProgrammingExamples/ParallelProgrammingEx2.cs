﻿////Example for creating tasks
//using System;
//using System.Threading.Tasks;


//    class ParallelProgrammingEx2
//    {
//    static void PrintMessage()
//    {
//        Console.WriteLine("Welcome to Accenture");
//    }

//    static void Main(string[] args)
//    {
//        Task myTask1 = new Task(PrintMessage);
//        Task myTask2 = new Task(() => Console.WriteLine("Welcome to MDC"));//lambda exp is an unnamed method written in place of delegate instance
//        myTask1.Start();
//        myTask2.Start();
//        Console.Read();
//    }
//    }

