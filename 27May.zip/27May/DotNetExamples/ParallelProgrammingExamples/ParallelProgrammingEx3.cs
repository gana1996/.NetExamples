﻿////Example for Tasks Life cycle
//using System;
//using System.Threading.Tasks;
//using System.Threading;

//class ParallelProgrammingEx3
//{
//    static void PrintMessage()
//    {
//        Console.WriteLine("Welcome to Accenture");
//    }

//    static void Main(string[] args)
//    {
//        Console.WriteLine("Starting main thread");
//        Task t1 = new Task(PrintMessage);
//        Console.WriteLine(t1.Status);//Task created
//        t1.Start();
//        Console.WriteLine(t1.Status);//waiting to run
//        Thread.Sleep(3000);
//        Console.WriteLine(t1.Status);//run to completion
//        Console.WriteLine("Ending main thread");
//    }
//}