﻿////Example for   Iteratoe
//using System;
//using System.Collections;

//class Employee
//{
//    int empNo;
//    string empName;
//    string[] workedLocations;

//    public Employee(int empNo,string empName,string[] workedLocations)
//    {
//        this.empNo = empNo;
//        this.empName = empName;
//        this.workedLocations = workedLocations;
//    }


//    public IEnumerable PrintEmpDetails()
//    {
//        yield return "EmpNo" + empNo;
//        yield return "EmpName" + empName;
//        yield return "I worked in";
//        foreach(string x in workedLocations)
//        {
//            yield return x;
//        }
//    }
//}

//class MainClass
//{
//    static void Main(string[] args)
//    {
//        Employee e1 = new Employee(1001, "Vivek Thatha", new string[] { "BDC", "MDC", "HDC" });
//        foreach(object y in e1.PrintEmpDetails())
//        {
//            Console.WriteLine(y);
//        }
//}
//}
    
