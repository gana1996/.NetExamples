﻿//  Example for varType is defined at compile time where as dynamic type is defined at run time
//using System;

//class  MyClass
//{
//    static void Main(string[] args)
//    {
//        var x = 10;
//        var string1 = "Accenture";
//        var y = true;
//        Console.WriteLine("Type of x:"+x.GetType()+"x="+x);
//        Console.WriteLine("Type of string1:" +string1.GetType() + "string1=" +string1);
//        Console.WriteLine("Type of y:" + y.GetType() + "y=" + y);
//    }
//}