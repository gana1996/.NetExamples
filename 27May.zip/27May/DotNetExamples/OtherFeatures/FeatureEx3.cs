﻿////Example for Partial cLASS
//using System;
//partial class MyClass
//{
//    public void PrintMethod1()
//    {
//        Console.WriteLine("Print Method1 is implemented");
//    }
//}

//partial class MyClass
//{
//    public void PrintMethod2()
//    {
//        Console.WriteLine("Print Method2 is implemented");
//    }
//}

//class MainClass
//{
//    static void Main(string[] args)
//    {
//        MyClass m1 = new MyClass();
//        m1.PrintMethod1();
//        m1.PrintMethod2();
//    }
//}
