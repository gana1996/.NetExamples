﻿////Example for Nullable Type
//using System;
//class MyClass
//{
//    static void Main(string[] args)
//    {
//        int? x = null;
//        if(x.HasValue==true)
//        {
//            Console.WriteLine("x"+x.Value);
//        }
//        else
//        {
//            Console.WriteLine("x=null");
//        }

//        int y = x.GetValueOrDefault();
//        Console.WriteLine("y="+y);

//        try
//        {
//            y = x.Value;
//        }
//        catch(InvalidOperationException ex)
//        {
//            Console.WriteLine("Exception:"+ex.Message);
//        }
//    }
//}