﻿//Example for Anonymous type-- we donot give any datatype
using System;
class MyClass
{
    static void Main(string[] args)
    {
        var Employee = new
        {
            empNo = 1001,
            empName = "Revs",
            salary = 50000.54
        };
        Console.WriteLine("EmpNo     "+Employee.empNo);
        Console.WriteLine("EmpName   " + Employee.empName);
        Console.WriteLine("Emp Salary   " + Employee.salary);
    }
}