﻿////Example for Inline Warning
//using System;
////#pragma warning disable 168
//#pragma warning disable 162
//#pragma warning disable 168
//class MyClass
//{
//    static void Main(string[] args)
//    {
//        int number;
//        if (false)
//        {
//            Console.WriteLine("accenture");
//        }
//    }
//}
    
