﻿////Example for Iterator 
//using System;
//using System.Collections;

//class MyClass
//{
//    public IEnumerator GetEnumerator()
//    {
//        for(int i=1;i<=5;i++)
//        {
//            yield return i;
//        }
//    }
//    static void Main(string[] args)
//    {
//        MyClass m1 = new MyClass();
//        foreach(int x in m1)
//        {
//            Console.WriteLine(x);
//        }
//    }
//}