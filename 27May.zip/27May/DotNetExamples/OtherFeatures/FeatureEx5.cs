﻿////Example for Global namespace specifier
//using System;
//class MyClass
//{
//    public class System
//    {

//    }
//    const int Console = 20;
//    static void Main(string[] args)
//    {
//        global::System.Console.WriteLine("Welcome to Mumbai");
//        global::System.Console.WriteLine(" Console:"+Console);
//    }
//}
