﻿////Example for Extension Method
//using System;
//static class MyClass
//{
//    public static string PrintName(this string firstName,string lastName)
//    {
//        return firstName + " " + lastName;
//    }
//}

//class MainClass
//{
//    static void Main(string[] args)
//    {
//        string fname = "Amit";
//        string Iname = fname.PrintName("Sharma");
//        Console.WriteLine(Iname);
//    }
//}